# Mixtape DS v0.5

A pocket Mixtape for the Nintendo 3DS, in the Mixtape black & white terminal look.
Top screen: now playing (cover, cassette or visualiser, or lyrics with ZR). Bottom screen: now · ~/library · ~/playlists · ⚙ settings.

## Build (GitHub Actions)
Upload `MixtapeDS-v0.5.zip` to the repo (delete the old zip). The workflow builds the newest zip it finds.
Download the `MixtapeDS` artifact from the run → `MixtapeDS.3dsx`.

## Install it on the HOME Menu (.cia)
The build makes two files: `MixtapeDS.3dsx` (Homebrew Launcher) and `MixtapeDS.cia` (a real HOME Menu app).
1. Copy `MixtapeDS.cia` to the SD card, e.g. `sdmc:/cias/`.
2. On the 3DS open **FBI** → SD → cias → `MixtapeDS.cia` → **Install CIA**.
3. Mixtape DS now has its own icon and banner on the HOME Menu. HOME and the power button work like any app.

## Your SD card
```
sdmc:/music/                 your MP3s (subfolders are fine)
sdmc:/music/playlists/*.m3u  playlists (Android paths from Mixtape are matched by file name)
sdmc:/music/.../song.lrc     synced lyrics, same name as the MP3 (or sdmc:/music/lyrics/song.lrc)
sdmc:/music/.../cover.jpg    album cover for a folder (embedded MP3 covers are used first)
sdmc:/3ds/MixtapeDS/         settings + tag cache (made automatically)
```
In Azahar: **File → Open Azahar Folder → sdmc** and use the same folders.

## Receive songs from your phone (v0.3)
1. 3DS: **SELECT → receive from phone** (Wi-Fi on, same network as the phone). It shows an address like `192.168.1.20:8080`.
2. Phone: **Mixtape → a playlist → send to 3DS** sends the missing songs, their lyrics and the playlist.
   Or open the address in any browser and pick files.
3. Press **B** when it's done: Mixtape DS adds the new songs to the library.

Files land in `sdmc:/music/` (playlists in `sdmc:/music/playlists/`). Only .mp3 .lrc .m3u .jpg .png are accepted.

## Controls
| Button | Everywhere |
|---|---|
| Y | pause / play |
| ZR | full lyrics on the top screen (B also works on the now tab) |
| L / R | switch tab |
| SELECT / ⚙ | settings (SELECT or B closes) |
| START | quit |

| Tab | Buttons |
|---|---|
| now | ← → previous / next · A pause · X shuffle · tap shuffle / repeat / a song in up next |
| ~/library | ↑ ↓ move · ← → jump letter · A play from here · X shuffle all · drag to scroll |
| ~/playlists | A open · X shuffle play · B back |
| settings | ↑ ↓ pick a row · ← → or A change it · tap anything |

## Settings
theme (b&w, terminal, amber, rose) · top screen (cover, cassette, visualiser) · lyrics (ZR to show, always on, off) ·
visualiser (bars, dots, wave, off) · lid closed (keep playing, pause) · tape stop on pause (off by default) · receive from phone.

If the footer says *audio failed to start*, the 3DS needs `sdmc:/3ds/dspfirm.cdc` (made once with the DSP1 homebrew; copy it into the emulator's `sdmc/3ds/` too).

Font: JetBrains Mono (SIL Open Font License, see `fonts/OFL.txt`).
