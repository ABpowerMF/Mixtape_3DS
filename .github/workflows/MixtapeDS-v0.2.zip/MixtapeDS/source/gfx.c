#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "gfx.h"

#ifdef HAVE_TURBOJPEG
#include <turbojpeg.h>
#endif
#ifdef HAVE_PNG
#include <png.h>
#endif

/* ================= palette ================= */

const char *THEME_NAMES[THEME_COUNT] = { "b&w", "terminal", "amber", "rose" };

static const u32 THEMES[THEME_COUNT][3] = {
    { 0x000000, 0xF2F2F2, 0xFFFFFF },   /* b&w (Mixtape default) */
    { 0x050805, 0xCFF5CF, 0x39FF6A },   /* terminal */
    { 0x0A0700, 0xFFE2A8, 0xFFB000 },   /* amber */
    { 0x1A1014, 0xF7E8EE, 0xFF6FA3 },   /* rose */
};

static u32 rgb_to_c2d(u32 rgb) {
    return C2D_Color32((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, 0xFF);
}

static u32 mix_rgb(u32 a, u32 b, float k) {
    int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
    int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
    int r = (int)lroundf(ar + (br - ar) * k);
    int g = (int)lroundf(ag + (bg - ag) * k);
    int bl = (int)lroundf(ab + (bb - ab) * k);
    return ((u32)r << 16) | ((u32)g << 8) | (u32)bl;
}

void theme_colors(int theme, u32 *bg, u32 *text, u32 *accent) {
    if (theme < 0 || theme >= THEME_COUNT) theme = 0;
    *bg = rgb_to_c2d(THEMES[theme][0]);
    *text = rgb_to_c2d(THEMES[theme][1]);
    *accent = rgb_to_c2d(THEMES[theme][2]);
}

Palette palette_make(int theme) {
    if (theme < 0 || theme >= THEME_COUNT) theme = 0;
    u32 b = THEMES[theme][0], t = THEMES[theme][1], a = THEMES[theme][2];
    Palette p;
    p.bg = rgb_to_c2d(b);
    p.text = rgb_to_c2d(t);
    p.accent = rgb_to_c2d(a);
    p.deep = rgb_to_c2d(mix_rgb(b, t, 0.07f));
    p.raised = rgb_to_c2d(mix_rgb(b, t, 0.10f));
    p.gap = rgb_to_c2d(mix_rgb(b, t, 0.20f));
    p.fog = rgb_to_c2d(mix_rgb(b, t, 0.58f));
    p.dim = rgb_to_c2d(mix_rgb(b, t, 0.42f));
    p.mid = rgb_to_c2d(mix_rgb(b, a, 0.78f));
    float lum = (0.2126f * ((a >> 16) & 0xFF) + 0.7152f * ((a >> 8) & 0xFF) + 0.0722f * (a & 0xFF)) / 255.0f;
    p.ink = lum > 0.35f ? C2D_Color32(0, 0, 0, 0xFF) : C2D_Color32(0xFF, 0xFF, 0xFF, 0xFF);
    return p;
}

/* ================= text ================= */

static C2D_TextBuf g_buf;        /* text drawn this frame */
static C2D_TextBuf g_measure;    /* scratch buffer for measuring, cleared every time */
static C2D_Font g_font = NULL, g_bold = NULL;
static bool g_romfs = false;
static float g_cell = 30.0f, g_cellBold = 30.0f;

static float cell_of(C2D_Font f) {
    FINF_s *info = C2D_FontGetInfo(f);
    if (info && info->tglp && info->tglp->cellHeight > 0) return (float)info->tglp->cellHeight;
    return 30.0f;
}

void gfx_init(void) {
    g_buf = C2D_TextBufNew(8192);
    g_measure = C2D_TextBufNew(1024);
    g_romfs = R_SUCCEEDED(romfsInit());
    if (g_romfs) {
        g_font = C2D_FontLoad("romfs:/mono.bcfnt");
        g_bold = C2D_FontLoad("romfs:/mono-bold.bcfnt");
    }
    if (!g_bold) g_bold = g_font;
    g_cell = cell_of(g_font);
    g_cellBold = cell_of(g_bold);
}

void gfx_exit(void) {
    if (g_bold && g_bold != g_font) C2D_FontFree(g_bold);
    if (g_font) C2D_FontFree(g_font);
    g_font = g_bold = NULL;
    C2D_TextBufDelete(g_buf);
    C2D_TextBufDelete(g_measure);
    if (g_romfs) romfsExit();
}

void gfx_frame_begin(void) { C2D_TextBufClear(g_buf); }
bool gfx_custom_font(void) { return g_font != NULL; }

static float scale_for(float px, int flags) {
    float cell = (flags & T_BOLD) ? g_cellBold : g_cell;
    return px * 1.32f / cell;
}

static C2D_Font font_for(int flags) { return (flags & T_BOLD) ? g_bold : g_font; }

/* width of s at px, using the scratch buffer */
static float measure(const char *s, float px, int flags) {
    if (!s || !*s) return 0.0f;
    C2D_TextBufClear(g_measure);
    C2D_Text t;
    C2D_TextFontParse(&t, font_for(flags), g_measure, s);
    float sc = scale_for(px, flags), w = 0, h = 0;
    C2D_TextGetDimensions(&t, sc, sc, &w, &h);
    return w;
}

float gfx_text_width(float px, int flags, const char *s) { return measure(s, px, flags); }

float gfx_text(float x, float y, float px, u32 col, const char *s, int flags, float maxw) {
    if (!s || !*s) return 0.0f;
    char buf[512];
    const char *draw = s;
    float w = measure(s, px, flags);

    if (maxw > 0 && w > maxw) {
        size_t len = strlen(s);
        if (len > sizeof(buf) - 4) len = sizeof(buf) - 4;
        size_t lo = 0, hi = len;
        while (lo < hi) {                       /* longest prefix that fits with "..." */
            size_t mid = (lo + hi + 1) / 2, cut = mid;
            while (cut > 0 && ((unsigned char)s[cut] & 0xC0) == 0x80) cut--;
            memcpy(buf, s, cut);
            strcpy(buf + cut, "...");
            if (measure(buf, px, flags) <= maxw) lo = mid; else hi = mid - 1;
        }
        size_t cut = lo;
        while (cut > 0 && ((unsigned char)s[cut] & 0xC0) == 0x80) cut--;
        memcpy(buf, s, cut);
        strcpy(buf + cut, "...");
        draw = buf;
        w = measure(draw, px, flags);
    }

    C2D_Text t;
    C2D_TextFontParse(&t, font_for(flags), g_buf, draw);
    u32 f = C2D_WithColor;
    if (flags & T_RIGHT) f |= C2D_AlignRight;
    else if (flags & T_CENTER) f |= C2D_AlignCenter;
    float sc = scale_for(px, flags);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, f, x, y, 0.5f, sc, sc, col);
    return w;
}

/* ================= shapes ================= */

void gfx_rect(float x, float y, float w, float h, u32 c) {
    if (w <= 0 || h <= 0) return;
    C2D_DrawRectSolid(x, y, 0.5f, w, h, c);
}

void gfx_rrect(float x, float y, float w, float h, float r, u32 c) {
    if (r <= 0.5f) { gfx_rect(x, y, w, h, c); return; }
    if (r > w / 2) r = w / 2;
    if (r > h / 2) r = h / 2;
    gfx_rect(x + r, y, w - 2 * r, h, c);
    gfx_rect(x, y + r, r, h - 2 * r, c);
    gfx_rect(x + w - r, y + r, r, h - 2 * r, c);
    C2D_DrawCircleSolid(x + r, y + r, 0.5f, r, c);
    C2D_DrawCircleSolid(x + w - r, y + r, 0.5f, r, c);
    C2D_DrawCircleSolid(x + r, y + h - r, 0.5f, r, c);
    C2D_DrawCircleSolid(x + w - r, y + h - r, 0.5f, r, c);
}

void gfx_frame(float x, float y, float w, float h, float t, u32 c) {
    gfx_rect(x, y, w, t, c);
    gfx_rect(x, y + h - t, w, t, c);
    gfx_rect(x, y + t, t, h - 2 * t, c);
    gfx_rect(x + w - t, y + t, t, h - 2 * t, c);
}

void gfx_line(float x0, float y0, float x1, float y1, float t, u32 c) {
    C2D_DrawLine(x0, y0, c, x1, y1, c, t, 0.5f);
}

static void tri(float x0, float y0, float x1, float y1, float x2, float y2, u32 c) {
    C2D_DrawTriangle(x0, y0, c, x1, y1, c, x2, y2, c, 0.5f);
}

/* ================= icons (s = icon size in px, centred on cx, cy) ================= */

void icon_prev(float cx, float cy, float s, u32 c) {
    float h = s * 0.66f, half = h / 2;
    float left = cx - s * 0.36f;
    gfx_rect(left, cy - half, s * 0.11f, h, c);
    tri(left + s * 0.14f, cy, cx + s * 0.36f, cy - half, cx + s * 0.36f, cy + half, c);
}

void icon_next(float cx, float cy, float s, u32 c) {
    float h = s * 0.66f, half = h / 2;
    float right = cx + s * 0.36f;
    gfx_rect(right - s * 0.11f, cy - half, s * 0.11f, h, c);
    tri(cx - s * 0.36f, cy - half, cx - s * 0.36f, cy + half, right - s * 0.14f, cy, c);
}

void icon_play(float cx, float cy, float s, u32 c) {
    float half = s * 0.34f;
    tri(cx - s * 0.26f, cy - half, cx - s * 0.26f, cy + half, cx + s * 0.34f, cy, c);
}

void icon_pause(float cx, float cy, float s, u32 c) {
    float h = s * 0.66f, w = s * 0.2f, gap = s * 0.16f;
    gfx_rrect(cx - gap / 2 - w, cy - h / 2, w, h, 1, c);
    gfx_rrect(cx + gap / 2, cy - h / 2, w, h, 1, c);
}

void icon_shuffle(float cx, float cy, float s, u32 c) {
    float l = cx - s / 2, r = cx + s / 2, t = cy - s * 0.36f, b = cy + s * 0.36f, th = s * 0.11f;
    if (th < 1.2f) th = 1.2f;
    gfx_line(l, b, r - s * 0.1f, t, th, c);
    gfx_line(l, t, l + s * 0.3f, t + s * 0.22f, th, c);
    gfx_line(cx + s * 0.08f, cy + s * 0.08f, r - s * 0.1f, b, th, c);
    float a = s * 0.22f;
    tri(r, t, r - a, t - a * 0.55f, r - a * 0.45f, t + a * 0.75f, c);
    tri(r, b, r - a * 0.45f, b - a * 0.75f, r - a, b + a * 0.55f, c);
}

void icon_repeat(float cx, float cy, float s, u32 c) {
    float l = cx - s / 2, r = cx + s / 2, t = cy - s * 0.3f, b = cy + s * 0.3f, th = s * 0.11f;
    if (th < 1.2f) th = 1.2f;
    float a = s * 0.2f;
    gfx_line(l + s * 0.05f, t, r - a, t, th, c);           /* top, arrow right */
    tri(r, t, r - a, t - a * 0.7f, r - a, t + a * 0.7f, c);
    gfx_line(l, t - th / 2, l, cy, th, c);                 /* left side down */
    gfx_line(r - s * 0.05f, b, l + a, b, th, c);           /* bottom, arrow left */
    tri(l, b, l + a, b - a * 0.7f, l + a, b + a * 0.7f, c);
    gfx_line(r, cy, r, b + th / 2, th, c);                 /* right side up */
}

void icon_gear(float cx, float cy, float s, u32 c, u32 hole) {
    float R = s * 0.34f;
    for (int i = 0; i < 8; i++) {
        float ang = (float)i * (float)M_PI / 4.0f;
        C2D_DrawCircleSolid(cx + cosf(ang) * R * 1.18f, cy + sinf(ang) * R * 1.18f, 0.5f, s * 0.12f, c);
    }
    C2D_DrawCircleSolid(cx, cy, 0.5f, R, c);
    C2D_DrawCircleSolid(cx, cy, 0.5f, s * 0.15f, hole);
}

void icon_battery(float x, float y, int level, bool charging, u32 frame, u32 fill) {
    gfx_frame(x, y, 14, 7, 1, frame);
    gfx_rect(x + 14, y + 2, 1.5f, 3, frame);
    if (level < 0) level = 0;
    if (level > 5) level = 5;
    float w = 10.0f * (float)level / 5.0f;
    if (charging) w = 10.0f;
    gfx_rect(x + 2, y + 2, w, 3, fill);
}

/* ================= cover art ================= */

#define COVER 128

void cover_clear(Cover *c) {
    if (c->ok) C3D_TexDelete(&c->tex);
    memset(c, 0, sizeof(*c));
}

/* Centre-crops rgba (w x h) to a square and box-samples it into the 128x128 texture. */
__attribute__((unused)) static bool upload_rgba(Cover *c, const unsigned char *rgba, int w, int h) {
    cover_clear(c);
    if (!C3D_TexInit(&c->tex, COVER, COVER, GPU_RGBA8)) return false;
    C3D_TexSetFilter(&c->tex, GPU_LINEAR, GPU_LINEAR);
    u32 *dst = (u32 *)c->tex.data;

    int side = w < h ? w : h;
    int ox = (w - side) / 2, oy = (h - side) / 2;
    float step = (float)side / COVER;

    for (int y = 0; y < COVER; y++) {
        for (int x = 0; x < COVER; x++) {
            int sx0 = ox + (int)(x * step), sy0 = oy + (int)(y * step);
            int sx1 = ox + (int)((x + 1) * step), sy1 = oy + (int)((y + 1) * step);
            if (sx1 <= sx0) sx1 = sx0 + 1;
            if (sy1 <= sy0) sy1 = sy0 + 1;
            if (sx1 > w) sx1 = w;
            if (sy1 > h) sy1 = h;
            unsigned r = 0, g = 0, b = 0, n = 0;
            for (int yy = sy0; yy < sy1; yy++)
                for (int xx = sx0; xx < sx1; xx++) {
                    const unsigned char *px = rgba + ((size_t)yy * w + xx) * 4;
                    r += px[0]; g += px[1]; b += px[2]; n++;
                }
            if (n == 0) n = 1;
            u32 texel = ((r / n) << 24) | ((g / n) << 16) | ((b / n) << 8) | 0xFF;
            u32 idx = ((((y >> 3) * (COVER >> 3) + (x >> 3)) << 6) +
                       ((x & 1) | ((y & 1) << 1) | ((x & 2) << 1) | ((y & 2) << 2) | ((x & 4) << 2) | ((y & 4) << 3)));
            dst[idx] = texel;
        }
    }
    C3D_TexFlush(&c->tex);

    c->sub.width = COVER;
    c->sub.height = COVER;
    c->sub.left = 0.0f;
    c->sub.top = 1.0f;
    c->sub.right = 1.0f;
    c->sub.bottom = 0.0f;
    c->img.tex = &c->tex;
    c->img.subtex = &c->sub;
    c->ok = true;
    return true;
}

#ifdef HAVE_TURBOJPEG
static bool decode_jpeg(Cover *c, const unsigned char *data, size_t size) {
    tjhandle tj = tjInitDecompress();
    if (!tj) return false;
    int w = 0, h = 0, ss = 0, cs = 0;
    bool ok = false;
    if (tjDecompressHeader3(tj, data, (unsigned long)size, &w, &h, &ss, &cs) == 0 && w > 0 && h > 0) {
        int nf = 0;
        tjscalingfactor *f = tjGetScalingFactors(&nf);
        int bw = w, bh = h;
        long bestArea = (long)w * h;
        for (int i = 0; f && i < nf; i++) {
            int sw = TJSCALED(w, f[i]), sh = TJSCALED(h, f[i]);
            if (sw >= COVER && sh >= COVER && (long)sw * sh < bestArea) { bw = sw; bh = sh; bestArea = (long)sw * sh; }
        }
        unsigned char *rgba = malloc((size_t)bw * bh * 4);
        if (rgba && tjDecompress2(tj, data, (unsigned long)size, rgba, bw, 0, bh, TJPF_RGBA, TJFLAG_FASTDCT) == 0)
            ok = upload_rgba(c, rgba, bw, bh);
        free(rgba);
    }
    tjDestroy(tj);
    return ok;
}
#endif

#ifdef HAVE_PNG
static bool decode_png(Cover *c, const unsigned char *data, size_t size) {
    png_image img;
    memset(&img, 0, sizeof img);
    img.version = PNG_IMAGE_VERSION;
    if (!png_image_begin_read_from_memory(&img, data, size)) return false;
    img.format = PNG_FORMAT_RGBA;
    if (img.width > 2048 || img.height > 2048) { png_image_free(&img); return false; }
    unsigned char *rgba = malloc(PNG_IMAGE_SIZE(img));
    bool ok = false;
    if (rgba && png_image_finish_read(&img, NULL, rgba, 0, NULL))
        ok = upload_rgba(c, rgba, (int)img.width, (int)img.height);
    else
        png_image_free(&img);
    free(rgba);
    return ok;
}
#endif

bool cover_load_bytes(Cover *c, const unsigned char *data, size_t size) {
    if (!data || size < 8) return false;
#ifdef HAVE_PNG
    if (data[0] == 0x89 && data[1] == 'P' && data[2] == 'N' && data[3] == 'G') return decode_png(c, data, size);
#endif
#ifdef HAVE_TURBOJPEG
    if (data[0] == 0xFF && data[1] == 0xD8) return decode_jpeg(c, data, size);
#endif
    (void)c;
    return false;
}

bool cover_load_file(Cover *c, const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    bool ok = false;
    if (n > 8 && n < 8 * 1024 * 1024) {
        unsigned char *buf = malloc((size_t)n);
        if (buf && fread(buf, 1, (size_t)n, f) == (size_t)n) ok = cover_load_bytes(c, buf, (size_t)n);
        free(buf);
    }
    fclose(f);
    return ok;
}

void cover_draw(const Cover *c, float x, float y, float size) {
    if (!c->ok) return;
    float sc = size / COVER;
    C2D_DrawImageAt(c->img, x, y, 0.5f, NULL, sc, sc);
}
