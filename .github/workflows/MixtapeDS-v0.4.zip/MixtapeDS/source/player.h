#pragma once
#include <stdbool.h>
#include <stddef.h>

bool player_init(void);           /* false if the DSP couldn't start */
void player_exit(void);

bool player_open(const char *path);
void player_stop(void);
void player_update(void);         /* call every frame: refills audio buffers, runs tape-stop ramps */

/* tape = slow the tape down / wind it back up instead of stopping instantly */
void player_set_paused(bool paused, bool tape);
void player_toggle_pause(bool tape);

bool player_is_open(void);
bool player_is_paused(void);      /* the state it's heading to (true during a tape-stop ramp) */
bool player_finished(void);       /* reached the end of the track */

double player_elapsed(void);      /* seconds */
double player_length(void);       /* seconds, 0 if unknown */

/* ID3 tags of the open track ("" when missing) */
const char *player_title(void);
const char *player_artist(void);
const char *player_album(void);
const char *player_year(void);

/* Embedded cover picture of the open track (NULL if none). Valid until the next open. */
const unsigned char *player_cover(size_t *size);

/* n spectrum levels 0..1 for the visualiser */
void player_levels(float *out, int n);
