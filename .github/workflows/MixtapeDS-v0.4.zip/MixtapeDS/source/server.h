#pragma once
#include <stdbool.h>

#ifndef SERVER_PORT
#define SERVER_PORT    8080
#endif
#define DISCOVERY_PORT 8081

typedef struct {
    bool running;
    char ip[32];
    char current[128];      /* file being received, "" when idle */
    long long done, total;  /* bytes of the current file */
    int received;           /* files saved this session */
    char last[128];         /* last file saved */
    char error[128];        /* last problem, "" if none */
    bool phoneSeen;         /* a phone or browser has talked to us */
} ServerStatus;

/* Starts Wi-Fi receiving (HTTP on SERVER_PORT, discovery on DISCOVERY_PORT). */
bool server_start(char *err, int errlen);
void server_stop(void);
bool server_running(void);
void server_status(ServerStatus *out);
/* True once if files were added since the last call (the library needs a rescan). */
bool server_take_changed(void);
