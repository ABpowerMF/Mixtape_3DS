#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>
#include <mpg123.h>
#include "library.h"

#define CACHE_DIR  "sdmc:/3ds/MixtapeDS"
#define CACHE_FILE "sdmc:/3ds/MixtapeDS/tags.cache"

Library lib;

/* ---------------- small helpers ---------------- */

const char *path_base(const char *path) {
    const char *s = strrchr(path, '/');
    return s ? s + 1 : path;
}

static char *dupstr(const char *s) { return strdup(s ? s : ""); }

static void set_str(char **dst, const char *s) {
    free(*dst);
    *dst = dupstr(s);
}

void fmt_secs(int secs, char *out, size_t n) {
    if (secs < 0) { snprintf(out, n, "-:--"); return; }
    snprintf(out, n, "%d:%02d", secs / 60, secs % 60);
}

char first_letter(const char *s) {
    while (s && *s && !isalnum((unsigned char)*s)) s++;
    if (!s || !*s) return '#';
    char c = (char)toupper((unsigned char)*s);
    return (c >= 'A' && c <= 'Z') ? c : '#';
}

static int has_ext(const char *name, const char *ext) {
    size_t n = strlen(name), e = strlen(ext);
    return n > e && strcasecmp(name + n - e, ext) == 0;
}

static int is_dir(const char *path) {
    struct stat st;
    return stat(path, &st) == 0 && S_ISDIR(st.st_mode);
}

static int file_exists(const char *path) {
    struct stat st;
    return stat(path, &st) == 0 && !S_ISDIR(st.st_mode);
}

static void trim(char *s) {
    size_t n = strlen(s);
    while (n > 0 && (s[n - 1] == '\n' || s[n - 1] == '\r' || s[n - 1] == ' ' || s[n - 1] == '\t')) s[--n] = '\0';
}

/* "Artist - Title.mp3" -> artist/title; "late_bus_home.mp3" -> "late bus home" + folder name */
static void names_from_path(const char *path, char **title, char **artist) {
    char name[256];
    snprintf(name, sizeof name, "%s", path_base(path));
    char *dot = strrchr(name, '.');
    if (dot && dot != name) *dot = '\0';
    for (char *c = name; *c; c++) if (*c == '_') *c = ' ';

    char *sep = strstr(name, " - ");
    if (sep) {
        *sep = '\0';
        set_str(artist, name);
        set_str(title, sep + 3);
        return;
    }
    set_str(title, name);

    char dir[512];
    snprintf(dir, sizeof dir, "%s", path);
    char *slash = strrchr(dir, '/');
    if (slash) *slash = '\0';
    const char *folder = path_base(dir);
    if (strcasecmp(folder, "music") == 0 || strchr(folder, ':')) set_str(artist, "unknown artist");
    else set_str(artist, folder);
}

static int add_track(const char *path) {
    if (lib.ntracks >= MAX_TRACKS) return -1;
    if (lib.ntracks % 256 == 0) {
        Track *nt = realloc(lib.tracks, sizeof(Track) * (size_t)(lib.ntracks + 256));
        if (!nt) return -1;
        lib.tracks = nt;
    }
    Track *t = &lib.tracks[lib.ntracks];
    memset(t, 0, sizeof *t);
    t->path = dupstr(path);
    t->secs = -1;
    names_from_path(path, &t->title, &t->artist);
    t->album = dupstr("");
    return lib.ntracks++;
}

/* ---------------- scanning ---------------- */

static void scan_dir(const char *dir, int depth) {
    if (depth > 5) return;
    DIR *d = opendir(dir);
    if (!d) return;
    struct dirent *ent;
    char path[512];
    while ((ent = readdir(d)) != NULL) {
        if (ent->d_name[0] == '.') continue;
        snprintf(path, sizeof path, "%s/%s", dir, ent->d_name);
        int dir_flag;
#ifdef DT_DIR
        if (ent->d_type == DT_DIR) dir_flag = 1;
        else if (ent->d_type == DT_REG) dir_flag = 0;
        else dir_flag = is_dir(path);
#else
        dir_flag = is_dir(path);
#endif
        if (dir_flag) scan_dir(path, depth + 1);
        else if (has_ext(ent->d_name, ".mp3")) add_track(path);
    }
    closedir(d);
}

static int cmp_title(const void *a, const void *b) {
    const Track *x = a, *y = b;
    int r = strcasecmp(x->title, y->title);
    return r ? r : strcasecmp(x->path, y->path);
}

/* Lookup indexes over the library (built after sorting) so big playlists load fast. */
static int *byPath = NULL, *byBase = NULL;

static int cmp_idx_path(const void *a, const void *b) {
    return strcmp(lib.tracks[*(const int *)a].path, lib.tracks[*(const int *)b].path);
}
static int cmp_idx_base(const void *a, const void *b) {
    return strcasecmp(path_base(lib.tracks[*(const int *)a].path), path_base(lib.tracks[*(const int *)b].path));
}

static void build_indexes(void) {
    byPath = malloc(sizeof(int) * (size_t)(lib.nlib ? lib.nlib : 1));
    byBase = malloc(sizeof(int) * (size_t)(lib.nlib ? lib.nlib : 1));
    if (!byPath || !byBase) { free(byPath); free(byBase); byPath = byBase = NULL; return; }
    for (int i = 0; i < lib.nlib; i++) byPath[i] = byBase[i] = i;
    qsort(byPath, (size_t)lib.nlib, sizeof(int), cmp_idx_path);
    qsort(byBase, (size_t)lib.nlib, sizeof(int), cmp_idx_base);
}

static void free_indexes(void) {
    free(byPath);
    free(byBase);
    byPath = byBase = NULL;
}

static int find_path(const char *path) {
    if (byPath) {
        int lo = 0, hi = lib.nlib - 1;
        while (lo <= hi) {
            int mid = (lo + hi) / 2;
            int r = strcmp(path, lib.tracks[byPath[mid]].path);
            if (r == 0) return byPath[mid];
            if (r < 0) hi = mid - 1; else lo = mid + 1;
        }
    }
    for (int i = lib.nlib; i < lib.ntracks; i++)        /* tracks added by playlists */
        if (strcmp(lib.tracks[i].path, path) == 0) return i;
    return -1;
}

static int find_base(const char *name) {
    if (!byBase) return -1;
    int lo = 0, hi = lib.nlib - 1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        int r = strcasecmp(name, path_base(lib.tracks[byBase[mid]].path));
        if (r == 0) return byBase[mid];
        if (r < 0) hi = mid - 1; else lo = mid + 1;
    }
    return -1;
}

/* ---------------- playlists ---------------- */

static void load_playlist(Playlist *p) {
    FILE *f = fopen(p->path, "r");
    if (!f) return;
    char dir[512];
    snprintf(dir, sizeof dir, "%s", p->path);
    char *slash = strrchr(dir, '/');
    if (slash) *slash = '\0';

    int cap = 0;
    char line[1024], cand[1600];
    int first = 1;
    while (fgets(line, sizeof line, f)) {
        char *s = line;
        if (first) {
            if ((unsigned char)s[0] == 0xEF && (unsigned char)s[1] == 0xBB && (unsigned char)s[2] == 0xBF) s += 3;
            first = 0;
        }
        trim(s);
        while (*s == ' ' || *s == '\t') s++;
        if (*s == '\0' || *s == '#') continue;
        for (char *c = s; *c; c++) if (*c == '\\') *c = '/';

        if (strncmp(s, "sdmc:", 5) == 0) snprintf(cand, sizeof cand, "%s", s);
        else if (s[0] == '/') snprintf(cand, sizeof cand, "sdmc:%s", s);
        else snprintf(cand, sizeof cand, "%s/%s", dir, s);

        int idx = find_path(cand);
        if (idx < 0) idx = find_base(path_base(s));          /* Android paths from Mixtape: match by file name */
        if (idx < 0 && file_exists(cand)) idx = add_track(cand);
        if (idx < 0) continue;

        if (p->count == cap) {
            int nc = cap ? cap * 2 : 32;
            int *ni = realloc(p->items, sizeof(int) * (size_t)nc);
            if (!ni) break;
            p->items = ni;
            cap = nc;
        }
        p->items[p->count++] = idx;
    }
    fclose(f);
}

static void scan_playlist_dir(const char *dir) {
    DIR *d = opendir(dir);
    if (!d) return;
    struct dirent *ent;
    while ((ent = readdir(d)) != NULL && lib.npls < MAX_PLAYLISTS) {
        if (ent->d_name[0] == '.') continue;
        if (!has_ext(ent->d_name, ".m3u") && !has_ext(ent->d_name, ".m3u8")) continue;
        Playlist *p = &lib.pls[lib.npls];
        memset(p, 0, sizeof *p);
        snprintf(p->path, sizeof p->path, "%s/%s", dir, ent->d_name);
        snprintf(p->name, sizeof p->name, "%s", ent->d_name);
        char *dot = strrchr(p->name, '.');
        if (dot) *dot = '\0';
        for (char *c = p->name; *c; c++) if (*c == '_') *c = ' ';
        lib.npls++;
    }
    closedir(d);
}

static int cmp_playlist(const void *a, const void *b) {
    return strcasecmp(((const Playlist *)a)->name, ((const Playlist *)b)->name);
}

int playlist_secs(const Playlist *p, bool *complete) {
    int total = 0;
    bool all = true;
    for (int i = 0; i < p->count; i++) {
        int s = lib.tracks[p->items[i]].secs;
        if (s < 0) all = false;
        else total += s;
    }
    if (complete) *complete = all;
    return total;
}

/* ---------------- tag cache ---------------- */

typedef struct { char *path, *title, *artist, *album; int secs; } CacheEntry;
static CacheEntry *cache = NULL;
static int ncache = 0;

static int cmp_cache(const void *a, const void *b) {
    return strcmp(((const CacheEntry *)a)->path, ((const CacheEntry *)b)->path);
}

static void load_cache(void) {
    FILE *f = fopen(CACHE_FILE, "r");
    if (!f) return;
    char line[2048];
    int cap = 0;
    while (fgets(line, sizeof line, f)) {
        trim(line);
        char *fields[5];
        int nf = 0;
        char *s = line;
        fields[nf++] = s;
        while (nf < 5 && (s = strchr(s, '\t')) != NULL) { *s++ = '\0'; fields[nf++] = s; }
        if (nf != 5) continue;
        if (ncache == cap) {
            int nc = cap ? cap * 2 : 256;
            CacheEntry *ne = realloc(cache, sizeof(CacheEntry) * (size_t)nc);
            if (!ne) break;
            cache = ne;
            cap = nc;
        }
        CacheEntry *e = &cache[ncache++];
        e->secs = atoi(fields[0]);
        e->title = dupstr(fields[1]);
        e->artist = dupstr(fields[2]);
        e->album = dupstr(fields[3]);
        e->path = dupstr(fields[4]);
    }
    fclose(f);
    if (ncache > 1) qsort(cache, (size_t)ncache, sizeof(CacheEntry), cmp_cache);
}

static void apply_cache(void) {
    for (int i = 0; i < lib.ntracks; i++) {
        CacheEntry key = { .path = lib.tracks[i].path };
        CacheEntry *e = ncache ? bsearch(&key, cache, (size_t)ncache, sizeof(CacheEntry), cmp_cache) : NULL;
        if (!e) continue;
        Track *t = &lib.tracks[i];
        if (e->title[0]) set_str(&t->title, e->title);
        if (e->artist[0]) set_str(&t->artist, e->artist);
        set_str(&t->album, e->album);
        t->secs = e->secs;
        t->probed = true;
    }
    for (int i = 0; i < ncache; i++) {
        free(cache[i].path); free(cache[i].title); free(cache[i].artist); free(cache[i].album);
    }
    free(cache);
    cache = NULL;
    ncache = 0;
}

static void clean_field(char *s) {
    for (; *s; s++) if (*s == '\t' || *s == '\n' || *s == '\r') *s = ' ';
}

void library_save_cache(void) {
    mkdir("sdmc:/3ds", 0777);
    mkdir(CACHE_DIR, 0777);
    FILE *f = fopen(CACHE_FILE, "w");
    if (!f) return;
    for (int i = 0; i < lib.ntracks; i++) {
        Track *t = &lib.tracks[i];
        if (!t->probed) continue;
        clean_field(t->title); clean_field(t->artist); clean_field(t->album);
        fprintf(f, "%d\t%s\t%s\t%s\t%s\n", t->secs, t->title, t->artist, t->album, t->path);
    }
    fclose(f);
}

/* ---------------- probing tags ---------------- */

static void v1_copy(char *dst, size_t n, const char *src, size_t len) {
    size_t k = len < n - 1 ? len : n - 1;
    memcpy(dst, src, k);
    dst[k] = '\0';
    while (k > 0 && (dst[k - 1] == ' ' || dst[k - 1] == '\0')) dst[--k] = '\0';
}

void library_probe(int idx) {
    if (idx < 0 || idx >= lib.ntracks) return;
    Track *t = &lib.tracks[idx];
    if (t->probed) return;
    t->probed = true;

    int err = 0;
    mpg123_handle *h = mpg123_new(NULL, &err);
    if (!h) return;
    if (mpg123_open(h, t->path) == MPG123_OK) {
        long rate = 0;
        int ch = 0, enc = 0;
        if (mpg123_getformat(h, &rate, &ch, &enc) == MPG123_OK && rate > 0) {
            off_t len = mpg123_length(h);
            if (len > 0) t->secs = (int)(len / rate);
        }
        mpg123_id3v1 *v1 = NULL;
        mpg123_id3v2 *v2 = NULL;
        if ((mpg123_meta_check(h) & MPG123_ID3) && mpg123_id3(h, &v1, &v2) == MPG123_OK) {
            char buf[256];
            if (v2 && v2->title && v2->title->fill) set_str(&t->title, v2->title->p);
            else if (v1) { v1_copy(buf, sizeof buf, v1->title, sizeof v1->title); if (buf[0]) set_str(&t->title, buf); }
            if (v2 && v2->artist && v2->artist->fill) set_str(&t->artist, v2->artist->p);
            else if (v1) { v1_copy(buf, sizeof buf, v1->artist, sizeof v1->artist); if (buf[0]) set_str(&t->artist, buf); }
            if (v2 && v2->album && v2->album->fill) set_str(&t->album, v2->album->p);
            else if (v1) { v1_copy(buf, sizeof buf, v1->album, sizeof v1->album); set_str(&t->album, buf); }
        }
        mpg123_close(h);
    }
    mpg123_delete(h);
}

void library_probe_some(int hint, int budget) {
    if (lib.ntracks == 0 || budget <= 0) return;
    if (hint < 0 || hint >= lib.ntracks) hint = 0;
    for (int k = 0; k < lib.ntracks && budget > 0; k++) {
        int i = (hint + k) % lib.ntracks;
        if (!lib.tracks[i].probed) { library_probe(i); budget--; }
    }
}

/* ---------------- load / free ---------------- */

void library_load(const char *root) {
    memset(&lib, 0, sizeof lib);
    mpg123_init();
    scan_dir(root, 0);
    load_cache();
    apply_cache();
    if (lib.ntracks > 1) qsort(lib.tracks, (size_t)lib.ntracks, sizeof(Track), cmp_title);
    lib.nlib = lib.ntracks;
    build_indexes();

    char sub[512];
    scan_playlist_dir(root);
    snprintf(sub, sizeof sub, "%s/playlists", root);
    scan_playlist_dir(sub);
    if (lib.npls > 1) qsort(lib.pls, (size_t)lib.npls, sizeof(Playlist), cmp_playlist);
    for (int i = 0; i < lib.npls; i++) load_playlist(&lib.pls[i]);
    free_indexes();
}

void library_free(void) {
    for (int i = 0; i < lib.ntracks; i++) {
        Track *t = &lib.tracks[i];
        free(t->path); free(t->title); free(t->artist); free(t->album);
    }
    free(lib.tracks);
    for (int i = 0; i < lib.npls; i++) free(lib.pls[i].items);
    memset(&lib, 0, sizeof lib);
}
