#pragma once
#include <3ds.h>
#include <citro2d.h>
#include <stdbool.h>

/* ---- palette (Mixtape themes: background, text, accent + derived shades) ---- */
typedef struct {
    u32 bg, text, accent;
    u32 deep, raised, gap, fog, dim, mid, ink;
} Palette;

enum { THEME_BW = 0, THEME_TERMINAL, THEME_AMBER, THEME_ROSE, THEME_COUNT };
extern const char *THEME_NAMES[THEME_COUNT];

Palette palette_make(int theme);
void theme_colors(int theme, u32 *bg, u32 *text, u32 *accent);

/* ---- text ---- */
enum { T_BOLD = 1, T_RIGHT = 2, T_CENTER = 4 };

void gfx_init(void);              /* loads the bundled mono font (falls back to the system font) */
void gfx_exit(void);
void gfx_frame_begin(void);       /* clears the per-frame text buffer */
bool gfx_custom_font(void);

/* Draws text at (x, y) = top-left (or right/centre edge with T_RIGHT/T_CENTER).
   px is the CSS-like font size. maxw > 0 truncates with "..." to fit. Returns drawn width. */
float gfx_text(float x, float y, float px, u32 col, const char *s, int flags, float maxw);
float gfx_text_width(float px, int flags, const char *s);

/* ---- shapes & icons ---- */
void gfx_rect(float x, float y, float w, float h, u32 c);
void gfx_rrect(float x, float y, float w, float h, float r, u32 c);
void gfx_frame(float x, float y, float w, float h, float t, u32 c);   /* outline */
void gfx_line(float x0, float y0, float x1, float y1, float t, u32 c);

void icon_prev(float cx, float cy, float s, u32 c);
void icon_next(float cx, float cy, float s, u32 c);
void icon_play(float cx, float cy, float s, u32 c);
void icon_pause(float cx, float cy, float s, u32 c);
void icon_shuffle(float cx, float cy, float s, u32 c);
void icon_repeat(float cx, float cy, float s, u32 c);
void icon_gear(float cx, float cy, float s, u32 c, u32 hole);
void icon_battery(float x, float y, int level, bool charging, u32 frame, u32 fill);

/* ---- cover art ---- */
typedef struct {
    C3D_Tex tex;
    Tex3DS_SubTexture sub;
    C2D_Image img;
    bool ok;
} Cover;

void cover_clear(Cover *c);
/* Decodes JPEG/PNG bytes (if the build has the decoders) into a 128x128 texture. */
bool cover_load_bytes(Cover *c, const unsigned char *data, size_t size);
bool cover_load_file(Cover *c, const char *path);
void cover_draw(const Cover *c, float x, float y, float size);
