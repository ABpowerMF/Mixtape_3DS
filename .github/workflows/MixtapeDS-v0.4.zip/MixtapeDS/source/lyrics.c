#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "lyrics.h"
#include "library.h"

static void add_line(Lyrics *l, int *cap, int ms, const char *text) {
    if (l->n == *cap) {
        int nc = *cap ? *cap * 2 : 64;
        LyricLine *nl = realloc(l->lines, sizeof(LyricLine) * (size_t)nc);
        if (!nl) return;
        l->lines = nl;
        *cap = nc;
    }
    l->lines[l->n].ms = ms;
    l->lines[l->n].text = strdup(text);
    if (l->lines[l->n].text) l->n++;
}

/* Parses "[mm:ss.xx]" at s; returns chars consumed (0 if not a time tag). */
static int parse_tag(const char *s, int *ms) {
    if (s[0] != '[' || !isdigit((unsigned char)s[1])) return 0;
    int i = 1, mm = 0, ss = 0, frac = 0, fdigits = 0;
    while (isdigit((unsigned char)s[i])) mm = mm * 10 + (s[i++] - '0');
    if (s[i++] != ':') return 0;
    if (!isdigit((unsigned char)s[i])) return 0;
    while (isdigit((unsigned char)s[i])) ss = ss * 10 + (s[i++] - '0');
    if (s[i] == '.' || s[i] == ':') {
        i++;
        while (isdigit((unsigned char)s[i])) {
            if (fdigits < 3) { frac = frac * 10 + (s[i] - '0'); fdigits++; }
            i++;
        }
    }
    if (s[i] != ']') return 0;
    while (fdigits < 3) { frac *= 10; fdigits++; }
    *ms = (mm * 60 + ss) * 1000 + frac;
    return i + 1;
}

static int cmp_line(const void *a, const void *b) {
    return ((const LyricLine *)a)->ms - ((const LyricLine *)b)->ms;
}

static bool load_file(const char *path, Lyrics *out) {
    FILE *f = fopen(path, "r");
    if (!f) return false;
    int cap = 0;
    char line[1024];
    int plain = 0;
    while (fgets(line, sizeof line, f)) {
        size_t n = strlen(line);
        while (n > 0 && (line[n - 1] == '\n' || line[n - 1] == '\r')) line[--n] = '\0';
        char *s = line;
        if ((unsigned char)s[0] == 0xEF && (unsigned char)s[1] == 0xBB && (unsigned char)s[2] == 0xBF) s += 3;

        int times[16], nt = 0, ms, k;
        while (nt < 16 && (k = parse_tag(s, &ms)) > 0) { times[nt++] = ms; s += k; }
        while (*s == ' ') s++;
        if (nt > 0) {
            for (int i = 0; i < nt; i++) add_line(out, &cap, times[i], *s ? s : "· · ·");
        } else if (s[0] != '[' && *s) {
            add_line(out, &cap, plain++ * 4000, s);   /* unsynced lyrics: shown as a plain list */
        }
    }
    fclose(f);
    out->synced = plain == 0;
    if (out->n > 1 && out->synced) qsort(out->lines, (size_t)out->n, sizeof(LyricLine), cmp_line);
    return out->n > 0;
}

bool lyrics_load(const char *mp3path, Lyrics *out) {
    memset(out, 0, sizeof *out);
    char base[512], path[600];
    snprintf(base, sizeof base, "%s", mp3path);
    char *dot = strrchr(base, '.');
    if (dot && dot > strrchr(base, '/')) *dot = '\0';

    snprintf(path, sizeof path, "%s.lrc", base);
    if (load_file(path, out)) return true;

    snprintf(path, sizeof path, "sdmc:/music/lyrics/%s.lrc", path_base(base));
    if (load_file(path, out)) return true;

    lyrics_free(out);
    return false;
}

void lyrics_free(Lyrics *l) {
    for (int i = 0; i < l->n; i++) free(l->lines[i].text);
    free(l->lines);
    memset(l, 0, sizeof *l);
}

int lyrics_index(const Lyrics *l, int ms) {
    if (!l->synced) return -1;
    int lo = 0, hi = l->n - 1, ans = -1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2;
        if (l->lines[mid].ms <= ms) { ans = mid; lo = mid + 1; }
        else hi = mid - 1;
    }
    return ans;
}
