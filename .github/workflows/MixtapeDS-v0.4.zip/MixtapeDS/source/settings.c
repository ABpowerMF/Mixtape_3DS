#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include "settings.h"
#include "gfx.h"

#define SETTINGS_FILE "sdmc:/3ds/MixtapeDS/settings.ini"

Settings cfg = { THEME_BW, VIEW_COVER, LYR_ZR, VIZ_BARS, LID_KEEP, 0, 0, REP_OFF };

static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

void settings_load(void) {
    FILE *f = fopen(SETTINGS_FILE, "r");
    if (!f) return;
    char line[128];
    while (fgets(line, sizeof line, f)) {
        char key[32];
        int val;
        if (sscanf(line, "%31[^=]=%d", key, &val) != 2) continue;
        if (!strcmp(key, "theme")) cfg.theme = clampi(val, 0, THEME_COUNT - 1);
        else if (!strcmp(key, "top")) cfg.topView = clampi(val, 0, VIEW_COUNT - 1);
        else if (!strcmp(key, "lyrics")) cfg.lyrics = clampi(val, 0, LYR_COUNT - 1);
        else if (!strcmp(key, "viz")) cfg.viz = clampi(val, 0, VIZ_COUNT - 1);
        else if (!strcmp(key, "lid")) cfg.lid = clampi(val, 0, LID_COUNT - 1);
        else if (!strcmp(key, "tapestop")) cfg.tapeStop = val ? 1 : 0;
        else if (!strcmp(key, "shuffle")) cfg.shuffle = val ? 1 : 0;
        else if (!strcmp(key, "repeat")) cfg.repeat = clampi(val, 0, REP_COUNT - 1);
    }
    fclose(f);
}

void settings_save(void) {
    mkdir("sdmc:/3ds", 0777);
    mkdir("sdmc:/3ds/MixtapeDS", 0777);
    FILE *f = fopen(SETTINGS_FILE, "w");
    if (!f) return;
    fprintf(f, "theme=%d\ntop=%d\nlyrics=%d\nviz=%d\nlid=%d\ntapestop=%d\nshuffle=%d\nrepeat=%d\n",
            cfg.theme, cfg.topView, cfg.lyrics, cfg.viz, cfg.lid, cfg.tapeStop, cfg.shuffle, cfg.repeat);
    fclose(f);
}
