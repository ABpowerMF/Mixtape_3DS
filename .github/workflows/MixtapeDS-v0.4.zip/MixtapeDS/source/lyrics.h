#pragma once
#include <stdbool.h>

typedef struct {
    int ms;
    char *text;
} LyricLine;

typedef struct {
    LyricLine *lines;
    int n;
    bool synced;
} Lyrics;

/* Looks for <song>.lrc next to the MP3, then sdmc:/music/lyrics/<song>.lrc */
bool lyrics_load(const char *mp3path, Lyrics *out);
void lyrics_free(Lyrics *l);
/* Index of the line being sung at `ms` (-1 before the first line). */
int lyrics_index(const Lyrics *l, int ms);
