#pragma once
#include <stdbool.h>
#include <stddef.h>

#define MAX_TRACKS    4096
#define MAX_PLAYLISTS 128

typedef struct {
    char *path;
    char *title;     /* from tags once probed, otherwise from the file name */
    char *artist;
    char *album;
    int secs;        /* -1 = unknown */
    bool probed;
} Track;

typedef struct {
    char name[96];
    char path[512];
    int *items;      /* indices into lib.tracks */
    int count;
} Playlist;

typedef struct {
    Track *tracks;
    int ntracks;     /* all known tracks (library + files only reached by playlists) */
    int nlib;        /* tracks[0..nlib) are the library, sorted A-Z */
    Playlist pls[MAX_PLAYLISTS];
    int npls;
} Library;

extern Library lib;

void library_load(const char *root);       /* scan root, read playlists, load the tag cache */
void library_free(void);
void library_save_cache(void);

/* Reads tags + length for one track (opens the file). */
void library_probe(int idx);
/* Probes up to `budget` not-yet-probed tracks, starting from `hint`. */
void library_probe_some(int hint, int budget);

int playlist_secs(const Playlist *p, bool *complete);

const char *path_base(const char *path);
void fmt_secs(int secs, char *out, size_t n);   /* "3:44", "?:??" when unknown */
char first_letter(const char *s);               /* 'A'..'Z' or '#' */
