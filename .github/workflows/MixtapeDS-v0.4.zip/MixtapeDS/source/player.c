#include <3ds.h>
#include <mpg123.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "player.h"

#define CH         0
#define NBUF       8
#define BUF_FRAMES 4096
#define WIN        512
#define RAMP_DOWN  0.55   /* seconds for a tape stop */
#define RAMP_UP    0.35   /* seconds to wind back up */

static ndspWaveBuf wbuf[NBUF];
static s16 *pcm[NBUF];
static bool queued[NBUF];

static mpg123_handle *mh = NULL;
static bool ready = false, opened = false, eof = false;
static bool paused = false;        /* target state */
static bool dspPaused = false;     /* actual channel state */
static long rate = 44100;
static int channels = 2;
static unsigned long long playedFrames = 0;
static long long lengthFrames = 0;
static char title[256], artist[256], album[256], year[16];
static unsigned char *coverData = NULL;
static size_t coverSize = 0;
static int metaTries = 0;
static float window_[WIN];

/* tape-stop ramp: 0 = none, -1 = slowing down, +1 = speeding up */
static int ramp = 0;
static u64 rampStart = 0;

bool player_init(void) {
    if (R_FAILED(ndspInit())) return false;
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    mpg123_init();

    for (int i = 0; i < NBUF; i++) {
        pcm[i] = linearAlloc(BUF_FRAMES * 2 * sizeof(s16));
        if (!pcm[i]) {
            for (int j = 0; j < i; j++) linearFree(pcm[j]);
            ndspExit();
            return false;
        }
        memset(&wbuf[i], 0, sizeof(ndspWaveBuf));
        wbuf[i].data_pcm16 = pcm[i];
        queued[i] = false;
    }
    for (int k = 0; k < WIN; k++)
        window_[k] = 0.5f - 0.5f * cosf(2.0f * (float)M_PI * k / (WIN - 1));
    ready = true;
    return true;
}

static void clear_meta(void) {
    title[0] = artist[0] = album[0] = year[0] = '\0';
    free(coverData);
    coverData = NULL;
    coverSize = 0;
    metaTries = 0;
}

static void close_track(void) {
    if (!ready) return;
    ndspChnWaveBufClear(CH);
    for (int i = 0; i < NBUF; i++) {
        queued[i] = false;
        wbuf[i].status = NDSP_WBUF_FREE;
    }
    if (mh) {
        mpg123_close(mh);
        mpg123_delete(mh);
        mh = NULL;
    }
    opened = false;
    eof = false;
    ramp = 0;
}

void player_exit(void) {
    if (!ready) return;
    close_track();
    clear_meta();
    for (int i = 0; i < NBUF; i++) linearFree(pcm[i]);
    mpg123_exit();
    ndspExit();
    ready = false;
}

static void copy_str(char *dst, size_t n, const mpg123_string *s) {
    if (s && s->p && s->fill) snprintf(dst, n, "%s", s->p);
}

static void copy_v1(char *dst, size_t n, const char *src, size_t len) {
    size_t k = len < n - 1 ? len : n - 1;
    memcpy(dst, src, k);
    dst[k] = '\0';
    while (k > 0 && (dst[k - 1] == ' ' || dst[k - 1] == '\0')) dst[--k] = '\0';
}

static void read_meta(void) {
    if (!mh || metaTries > 6) return;
    metaTries++;
    if (!(mpg123_meta_check(mh) & MPG123_ID3)) return;
    mpg123_id3v1 *v1 = NULL;
    mpg123_id3v2 *v2 = NULL;
    if (mpg123_id3(mh, &v1, &v2) != MPG123_OK) return;
    if (v2) {
        copy_str(title, sizeof title, v2->title);
        copy_str(artist, sizeof artist, v2->artist);
        copy_str(album, sizeof album, v2->album);
        copy_str(year, sizeof year, v2->year);
        if (!coverData && v2->pictures > 0) {
            mpg123_picture *best = NULL;
            for (size_t i = 0; i < v2->pictures; i++) {
                mpg123_picture *pic = &v2->picture[i];
                if (!pic->data || pic->size < 8) continue;
                if (!best || pic->type == 3) best = pic;   /* 3 = front cover */
            }
            if (best) {
                coverData = malloc(best->size);
                if (coverData) {
                    memcpy(coverData, best->data, best->size);
                    coverSize = best->size;
                }
            }
        }
    }
    if (v1) {
        if (!title[0]) copy_v1(title, sizeof title, v1->title, sizeof v1->title);
        if (!artist[0]) copy_v1(artist, sizeof artist, v1->artist, sizeof v1->artist);
        if (!album[0]) copy_v1(album, sizeof album, v1->album, sizeof v1->album);
        if (!year[0]) copy_v1(year, sizeof year, v1->year, sizeof v1->year);
    }
    metaTries = 99;
}

bool player_open(const char *path) {
    if (!ready) return false;
    close_track();
    clear_meta();

    int err = 0;
    mh = mpg123_new(NULL, &err);
    if (!mh) return false;
    mpg123_param(mh, MPG123_ADD_FLAGS, MPG123_PICTURE, 0.0);
    if (mpg123_open(mh, path) != MPG123_OK) goto fail;

    int enc = 0;
    if (mpg123_getformat(mh, &rate, &channels, &enc) != MPG123_OK) goto fail;
    if (channels < 1 || channels > 2) goto fail;
    mpg123_format_none(mh);
    mpg123_format(mh, rate, channels, MPG123_ENC_SIGNED_16);

    lengthFrames = (long long)mpg123_length(mh);
    if (lengthFrames < 0) lengthFrames = 0;

    ndspChnReset(CH);
    ndspChnSetInterp(CH, NDSP_INTERP_POLYPHASE);
    ndspChnSetRate(CH, (float)rate);
    ndspChnSetFormat(CH, channels == 2 ? NDSP_FORMAT_STEREO_PCM16 : NDSP_FORMAT_MONO_PCM16);
    float mix[12];
    memset(mix, 0, sizeof mix);
    mix[0] = 1.0f;
    mix[1] = 1.0f;
    ndspChnSetMix(CH, mix);

    playedFrames = 0;
    paused = false;
    dspPaused = false;
    ramp = 0;
    ndspChnSetPaused(CH, false);
    opened = true;
    eof = false;
    read_meta();
    player_update();
    return true;

fail:
    mpg123_delete(mh);
    mh = NULL;
    return false;
}

void player_stop(void) {
    close_track();
    clear_meta();
}

static void run_ramp(void) {
    if (!ramp) return;
    double t = (double)(osGetTime() - rampStart) / 1000.0;
    if (ramp < 0) {
        double k = 1.0 - t / RAMP_DOWN;
        if (k <= 0.02) {
            ndspChnSetPaused(CH, true);
            dspPaused = true;
            ndspChnSetRate(CH, (float)rate);
            ramp = 0;
        } else {
            ndspChnSetRate(CH, (float)(rate * k * k));
        }
    } else {
        double k = t / RAMP_UP;
        if (k >= 1.0) {
            ndspChnSetRate(CH, (float)rate);
            ramp = 0;
        } else {
            double f = 0.15 + 0.85 * k;
            ndspChnSetRate(CH, (float)(rate * f));
        }
    }
}

void player_update(void) {
    if (!opened) return;
    run_ramp();

    for (int i = 0; i < NBUF; i++) {
        if (queued[i] && wbuf[i].status == NDSP_WBUF_DONE) {
            playedFrames += wbuf[i].nsamples;
            queued[i] = false;
        }
    }

    for (int i = 0; i < NBUF && !eof; i++) {
        if (queued[i]) continue;
        size_t want = (size_t)BUF_FRAMES * (size_t)channels * sizeof(s16);
        size_t got = 0;
        int tries = 0;
        while (got < want) {
            size_t done = 0;
            int r = mpg123_read(mh, (unsigned char *)pcm[i] + got, want - got, &done);
            got += done;
            if (r == MPG123_DONE) { eof = true; break; }
            if (done == 0 && ++tries > 8) { eof = true; break; }
        }
        if (got == 0) continue;
        wbuf[i].nsamples = (u32)(got / ((size_t)channels * sizeof(s16)));
        DSP_FlushDataCache(pcm[i], (u32)got);
        ndspChnWaveBufAdd(CH, &wbuf[i]);
        queued[i] = true;
        read_meta();
    }
}

void player_set_paused(bool p, bool tape) {
    if (!opened || p == paused) return;
    paused = p;
    if (p) {
        if (tape) {
            ramp = -1;
            rampStart = osGetTime();
        } else {
            ramp = 0;
            ndspChnSetRate(CH, (float)rate);
            ndspChnSetPaused(CH, true);
            dspPaused = true;
        }
    } else {
        ndspChnSetPaused(CH, false);
        dspPaused = false;
        if (tape) {
            ramp = 1;
            rampStart = osGetTime();
            ndspChnSetRate(CH, (float)(rate * 0.15));
        } else {
            ramp = 0;
            ndspChnSetRate(CH, (float)rate);
        }
    }
}

void player_toggle_pause(bool tape) { player_set_paused(!paused, tape); }

bool player_is_open(void) { return opened; }
bool player_is_paused(void) { return opened && paused; }

bool player_finished(void) {
    if (!opened || !eof) return false;
    for (int i = 0; i < NBUF; i++)
        if (queued[i]) return false;
    return true;
}

double player_elapsed(void) {
    if (!opened || rate <= 0) return 0.0;
    return (double)(playedFrames + ndspChnGetSamplePos(CH)) / (double)rate;
}

double player_length(void) {
    if (!opened || rate <= 0) return 0.0;
    return (double)lengthFrames / (double)rate;
}

const char *player_title(void) { return title; }
const char *player_artist(void) { return artist; }
const char *player_album(void) { return album; }
const char *player_year(void) { return year; }

const unsigned char *player_cover(size_t *size) {
    if (size) *size = coverSize;
    return coverData;
}

void player_levels(float *out, int n) {
    for (int b = 0; b < n; b++) out[b] = 0.0f;
    if (!opened || dspPaused || n < 2) return;

    int cur = -1;
    for (int i = 0; i < NBUF; i++)
        if (queued[i] && wbuf[i].status == NDSP_WBUF_PLAYING) { cur = i; break; }
    if (cur < 0) return;

    u32 frames = wbuf[cur].nsamples;
    if (frames < WIN) return;
    u32 start = ndspChnGetSamplePos(CH);
    if (start + WIN > frames) start = frames - WIN;

    static float x[WIN];
    const s16 *src = pcm[cur];
    for (int k = 0; k < WIN; k++) {
        float v;
        if (channels == 2) v = ((float)src[(start + k) * 2] + (float)src[(start + k) * 2 + 1]) * 0.5f;
        else v = (float)src[start + k];
        x[k] = v / 32768.0f * window_[k];
    }

    for (int b = 0; b < n; b++) {
        float f = 60.0f * powf(14000.0f / 60.0f, (float)b / (float)(n - 1));
        float w = 2.0f * (float)M_PI * f / (float)rate;
        float coeff = 2.0f * cosf(w);
        float s1 = 0.0f, s2 = 0.0f;
        for (int k = 0; k < WIN; k++) {
            float s = x[k] + coeff * s1 - s2;
            s2 = s1;
            s1 = s;
        }
        float power = s1 * s1 + s2 * s2 - coeff * s1 * s2;
        if (power < 0.0f) power = 0.0f;
        float mag = sqrtf(power) / (WIN * 0.25f);
        float db = 20.0f * log10f(mag + 1e-6f);
        float v = (db + 54.0f) / 54.0f;
        out[b] = v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
    }
}
