#pragma once

enum { VIEW_COVER = 0, VIEW_CASSETTE, VIEW_VISUALISER, VIEW_COUNT };
enum { LYR_ZR = 0, LYR_ALWAYS, LYR_OFF, LYR_COUNT };
enum { VIZ_BARS = 0, VIZ_DOTS, VIZ_WAVE, VIZ_OFF, VIZ_COUNT };
enum { LID_KEEP = 0, LID_PAUSE, LID_COUNT };
enum { REP_OFF = 0, REP_ALL, REP_ONE, REP_COUNT };

typedef struct {
    int theme;
    int topView;
    int lyrics;
    int viz;
    int lid;
    int tapeStop;
    int shuffle;
    int repeat;
} Settings;

extern Settings cfg;

void settings_load(void);
void settings_save(void);
