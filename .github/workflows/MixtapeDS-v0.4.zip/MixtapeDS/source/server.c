/* Wi-Fi receiver: Mixtape on the phone (or any browser) sends MP3s, lyrics and playlists
   straight into sdmc:/music.

   HTTP on port 8080, one connection at a time, "Connection: close":
     GET  /             upload page for a browser
     GET  /api/info     {"app":"MixtapeDS","version":"...","songs":N}
     GET  /api/list     one file name per line: the MP3s already on the card
     PUT  /api/file?path=<relative path under music/>   body = the file (POST works too)
     POST /api/done     the phone finished: the library is rescanned
   UDP discovery on 8081: "MIXTAPE-DS?" -> "MIXTAPE-DS 8080 <version>" */
#include <3ds.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <malloc.h>
#include <netinet/in.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>
#include "library.h"
#include "server.h"

#define MUSIC_DIR  "sdmc:/music"
#define SOC_ALIGN  0x1000
#define SOC_SIZE   0x100000
#define CHUNK      (32 * 1024)
#define MAX_NAMES  4096

extern const char *APP_VERSION_STR;

static u32 *socBuf = NULL;
static Thread thread = NULL;
static volatile bool stopFlag = false;
static bool started = false;
static LightLock lock;
static ServerStatus st;
static volatile bool changed = false;

/* names received this session (so /api/list includes them before a rescan) */
static char *names[MAX_NAMES];
static int nnames = 0;

/* ---------------- status helpers ---------------- */

static void set_error(const char *msg) {
    LightLock_Lock(&lock);
    snprintf(st.error, sizeof st.error, "%s", msg);
    LightLock_Unlock(&lock);
}

static void set_current(const char *name, long long total) {
    LightLock_Lock(&lock);
    snprintf(st.current, sizeof st.current, "%s", name);
    st.done = 0;
    st.total = total;
    st.phoneSeen = true;
    LightLock_Unlock(&lock);
}

static void set_progress(long long done) {
    LightLock_Lock(&lock);
    st.done = done;
    LightLock_Unlock(&lock);
}

void server_status(ServerStatus *out) {
    if (!started) { memset(out, 0, sizeof *out); return; }
    LightLock_Lock(&lock);
    *out = st;
    LightLock_Unlock(&lock);
}

bool server_take_changed(void) {
    bool c = changed;
    changed = false;
    return c;
}

bool server_running(void) { return started; }

/* ---------------- small HTTP helpers ---------------- */

static bool send_all(int fd, const void *data, size_t len) {
    const char *p = data;
    while (len > 0) {
        ssize_t n = send(fd, p, len, 0);
        if (n <= 0) return false;
        p += n;
        len -= (size_t)n;
    }
    return true;
}

static void respond(int fd, int code, const char *type, const char *body, size_t len) {
    const char *text = code == 200 ? "OK" : code == 400 ? "Bad Request" : code == 404 ? "Not Found" : "Error";
    char head[256];
    int n = snprintf(head, sizeof head,
                     "HTTP/1.1 %d %s\r\nContent-Type: %s\r\nContent-Length: %u\r\n"
                     "Access-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n",
                     code, text, type, (unsigned)len);
    send_all(fd, head, (size_t)n);
    if (len) send_all(fd, body, len);
}

static void respond_text(int fd, int code, const char *msg) {
    respond(fd, code, "text/plain; charset=utf-8", msg, strlen(msg));
}

static int hexval(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static void url_decode(const char *src, char *dst, size_t n) {
    size_t o = 0;
    for (size_t i = 0; src[i] && src[i] != '&' && o + 1 < n; i++) {
        if (src[i] == '%' && hexval(src[i + 1]) >= 0 && hexval(src[i + 2]) >= 0) {
            dst[o++] = (char)(hexval(src[i + 1]) * 16 + hexval(src[i + 2]));
            i += 2;
        } else if (src[i] == '+') {
            dst[o++] = ' ';
        } else {
            dst[o++] = src[i];
        }
    }
    dst[o] = '\0';
}

static bool query_param(const char *target, const char *key, char *out, size_t n) {
    const char *q = strchr(target, '?');
    if (!q) return false;
    q++;
    size_t klen = strlen(key);
    while (*q) {
        if (strncmp(q, key, klen) == 0 && q[klen] == '=') {
            url_decode(q + klen + 1, out, n);
            return true;
        }
        q = strchr(q, '&');
        if (!q) break;
        q++;
    }
    return false;
}

/* ---------------- files ---------------- */

static bool allowed_ext(const char *p) {
    const char *dot = strrchr(p, '.');
    if (!dot) return false;
    const char *ok[] = { ".mp3", ".lrc", ".m3u", ".m3u8", ".jpg", ".jpeg", ".png" };
    for (unsigned i = 0; i < sizeof ok / sizeof ok[0]; i++)
        if (strcasecmp(dot, ok[i]) == 0) return true;
    return false;
}

/* Cleans a relative path from the phone. Returns false if it isn't safe. */
static bool clean_path(const char *in, char *out, size_t n) {
    if (!in[0] || strlen(in) > 220) return false;
    size_t o = 0;
    for (size_t i = 0; in[i] && o + 1 < n; i++) {
        char c = in[i];
        if (c == '\\') c = '/';
        if (c == ':' || c == '*' || c == '?' || c == '"' || c == '<' || c == '>' || c == '|' || (unsigned char)c < 32) c = '_';
        out[o++] = c;
    }
    out[o] = '\0';
    while (out[0] == '/') memmove(out, out + 1, strlen(out));
    if (!out[0]) return false;
    /* refuse "." and ".." folders (names like "Hello... (Remix).mp3" are fine) */
    const char *seg = out;
    while (*seg) {
        const char *end = strchr(seg, '/');
        size_t len = end ? (size_t)(end - seg) : strlen(seg);
        if (len == 0 || (len == 1 && seg[0] == '.') || (len == 2 && seg[0] == '.' && seg[1] == '.')) return false;
        seg += len;
        if (*seg == '/') seg++;
    }
    return allowed_ext(out);
}

static void make_dirs(const char *full) {
    char tmp[512];
    snprintf(tmp, sizeof tmp, "%s", full);
    for (char *p = tmp + strlen("sdmc:/"); *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0777);
            *p = '/';
        }
    }
}

static void remember_name(const char *rel) {
    if (nnames >= MAX_NAMES) return;
    names[nnames] = strdup(path_base(rel));
    if (names[nnames]) nnames++;
}

static void handle_put(int fd, const char *target, long long len, const char *already, size_t alreadyLen) {
    char raw[300], rel[300], full[600], part[620];
    if (!query_param(target, "path", raw, sizeof raw) || !clean_path(raw, rel, sizeof rel)) {
        respond_text(fd, 400, "bad path (only .mp3 .lrc .m3u .jpg .png inside music/)");
        return;
    }
    if (len <= 0 || len > 400LL * 1024 * 1024) { respond_text(fd, 400, "missing or too large Content-Length"); return; }

    snprintf(full, sizeof full, "%s/%s", MUSIC_DIR, rel);
    snprintf(part, sizeof part, "%s.part", full);
    make_dirs(full);
    FILE *f = fopen(part, "wb");
    if (!f) { set_error("couldn't write to the SD card"); respond_text(fd, 500, "couldn't write to the SD card"); return; }
    setvbuf(f, NULL, _IOFBF, 64 * 1024);

    set_current(path_base(rel), len);
    long long got = 0;
    bool ok = true;
    if (alreadyLen > 0) {
        size_t take = alreadyLen > (size_t)len ? (size_t)len : alreadyLen;
        if (fwrite(already, 1, take, f) != take) ok = false;
        got += (long long)take;
    }
    char *buf = malloc(CHUNK);
    if (!buf) ok = false;
    while (ok && got < len && !stopFlag) {
        struct pollfd pfd = { .fd = fd, .events = POLLIN };
        if (poll(&pfd, 1, 15000) <= 0) { ok = false; break; }    /* phone went quiet */
        long long want = len - got;
        ssize_t n = recv(fd, buf, want > CHUNK ? CHUNK : (size_t)want, 0);
        if (n <= 0) { ok = false; break; }
        if (fwrite(buf, 1, (size_t)n, f) != (size_t)n) { ok = false; break; }
        got += n;
        set_progress(got);
    }
    free(buf);
    fclose(f);

    if (!ok || got != len) {
        remove(part);
        set_current("", 0);
        set_error(stopFlag ? "stopped" : "a transfer was cut off");
        respond_text(fd, 500, "transfer cut off");
        return;
    }
    remove(full);
    if (rename(part, full) != 0) {
        remove(part);
        set_current("", 0);
        set_error("couldn't save a file");
        respond_text(fd, 500, "couldn't save");
        return;
    }
    remember_name(rel);
    changed = true;
    LightLock_Lock(&lock);
    st.received++;
    snprintf(st.last, sizeof st.last, "%s", path_base(rel));
    st.current[0] = '\0';
    st.error[0] = '\0';
    LightLock_Unlock(&lock);
    respond_text(fd, 200, "ok");
}

static void handle_list(int fd) {
    /* library paths are only read here; the main thread doesn't rescan while receiving */
    size_t cap = 64 * 1024, len = 0;
    char *out = malloc(cap);
    if (!out) { respond_text(fd, 500, "out of memory"); return; }
    for (int i = 0; i < lib.ntracks + nnames; i++) {
        const char *b = i < lib.ntracks ? path_base(lib.tracks[i].path) : names[i - lib.ntracks];
        size_t bl = strlen(b);
        if (len + bl + 2 > cap) {
            cap *= 2;
            char *no = realloc(out, cap);
            if (!no) break;
            out = no;
        }
        memcpy(out + len, b, bl);
        len += bl;
        out[len++] = '\n';
    }
    respond(fd, 200, "text/plain; charset=utf-8", out, len);
    free(out);
}

/* ---------------- browser page ---------------- */

static const char PAGE[] =
"<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
"<title>Mixtape DS</title><style>"
"body{margin:0;background:#000;color:#F2F2F2;font-family:ui-monospace,Menlo,Consolas,monospace;padding:24px 18px}"
"h1{font-size:18px;margin:0 0 4px}p{color:#8A8A8A;font-size:13px;line-height:1.5}"
"label{display:block;border:1px dashed #3A3A3A;border-radius:3px;padding:28px 12px;text-align:center;margin:18px 0;cursor:pointer}"
"input{display:none}button{background:#fff;color:#000;border:0;border-radius:3px;font:inherit;font-weight:700;padding:12px 18px;width:100%}"
"#log div{font-size:12px;padding:5px 0;border-bottom:1px solid #141414;color:#8A8A8A}#log .ok{color:#F2F2F2}"
".bar{height:3px;background:#2A2A2A;margin-top:4px}.bar i{display:block;height:3px;background:#fff;width:0}"
"</style></head><body><h1>~/mixtape-ds</h1>"
"<p>Pick MP3s (and .lrc lyrics or .m3u playlists). They go straight to music/ on the 3DS.</p>"
"<label>[ pick files ]<input id='f' type='file' multiple accept='.mp3,.lrc,.m3u,.m3u8,audio/mpeg'></label>"
"<button id='go'>send to 3DS</button><div id='log'></div><script>"
"const f=document.getElementById('f'),log=document.getElementById('log');"
"f.onchange=()=>{log.innerHTML='';for(const x of f.files){const d=document.createElement('div');d.textContent=x.name;log.appendChild(d)}};"
"function put(x,row){return new Promise(r=>{const q=new XMLHttpRequest();const b=document.createElement('div');b.className='bar';"
"const i=document.createElement('i');b.appendChild(i);row.appendChild(b);"
"q.open('PUT','/api/file?path='+encodeURIComponent((/\\.m3u8?$/i.test(x.name)?'playlists/':'')+x.name));"
"q.upload.onprogress=e=>{if(e.lengthComputable)i.style.width=(100*e.loaded/e.total)+'%'};"
"q.onload=()=>{row.className=q.status==200?'ok':'';row.firstChild.textContent=(q.status==200?'> ':'x ')+x.name;b.remove();r()};"
"q.onerror=()=>{row.firstChild.textContent='x '+x.name;b.remove();r()};q.send(x)})}"
"document.getElementById('go').onclick=async()=>{const rows=log.children;let k=0;"
"for(const x of f.files){await put(x,rows[k++])}await fetch('/api/done',{method:'POST'});"
"const d=document.createElement('div');d.className='ok';d.textContent='done. the 3DS adds them when you close the receive screen.';log.appendChild(d)};"
"</script></body></html>";

/* ---------------- connection ---------------- */

static void handle_client(int fd) {
    char req[4096];
    size_t len = 0;
    char *end = NULL;
    while (len < sizeof req - 1) {
        struct pollfd pfd = { .fd = fd, .events = POLLIN };
        if (poll(&pfd, 1, 5000) <= 0) return;
        ssize_t n = recv(fd, req + len, sizeof req - 1 - len, 0);
        if (n <= 0) return;
        len += (size_t)n;
        req[len] = '\0';
        if ((end = strstr(req, "\r\n\r\n")) != NULL) break;
    }
    if (!end) { respond_text(fd, 400, "headers too long"); return; }
    *end = '\0';
    const char *body = end + 4;
    size_t bodyLen = len - (size_t)(body - req);

    char method[8] = "", target[1024] = "";
    sscanf(req, "%7s %1023s", method, target);
    long long clen = -1;
    for (char *h = strstr(req, "\r\n"); h; h = strstr(h + 2, "\r\n")) {
        if (strncasecmp(h + 2, "Content-Length:", 15) == 0) clen = atoll(h + 17);
    }

    LightLock_Lock(&lock);
    st.phoneSeen = true;
    LightLock_Unlock(&lock);

    char route[256];
    snprintf(route, sizeof route, "%.255s", target);
    char *qm = strchr(route, '?');
    if (qm) *qm = '\0';

    if (!strcmp(method, "OPTIONS")) {
        const char *h = "HTTP/1.1 204 No Content\r\nAccess-Control-Allow-Origin: *\r\n"
                        "Access-Control-Allow-Methods: GET, PUT, POST\r\nAccess-Control-Allow-Headers: *\r\nConnection: close\r\n\r\n";
        send_all(fd, h, strlen(h));
    } else if (!strcmp(method, "GET") && !strcmp(route, "/")) {
        respond(fd, 200, "text/html; charset=utf-8", PAGE, sizeof PAGE - 1);
    } else if (!strcmp(method, "GET") && !strcmp(route, "/api/info")) {
        char js[160];
        snprintf(js, sizeof js, "{\"app\":\"MixtapeDS\",\"version\":\"%s\",\"songs\":%d}", APP_VERSION_STR, lib.nlib + nnames);
        respond(fd, 200, "application/json", js, strlen(js));
    } else if (!strcmp(method, "GET") && !strcmp(route, "/api/list")) {
        handle_list(fd);
    } else if ((!strcmp(method, "PUT") || !strcmp(method, "POST")) && !strcmp(route, "/api/file")) {
        handle_put(fd, target, clen, body, bodyLen);
    } else if (!strcmp(method, "POST") && !strcmp(route, "/api/done")) {
        respond_text(fd, 200, "ok");
    } else {
        respond_text(fd, 404, "not found");
    }
}

/* ---------------- thread ---------------- */

static void server_thread(void *arg) {
    (void)arg;
    int tcp = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
    int udp = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
    if (tcp < 0 || udp < 0) { set_error("couldn't open a network socket"); goto out; }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(SERVER_PORT);
    int one = 1;
    setsockopt(tcp, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);   /* reopening the screen right away */
    if (bind(tcp, (struct sockaddr *)&addr, sizeof addr) < 0 || listen(tcp, 2) < 0) {
        set_error("port 8080 is busy");
        goto out;
    }
    addr.sin_port = htons(DISCOVERY_PORT);
    bind(udp, (struct sockaddr *)&addr, sizeof addr);   /* discovery is optional */

    while (!stopFlag) {
        struct pollfd pf[2] = { { .fd = tcp, .events = POLLIN }, { .fd = udp, .events = POLLIN } };
        int r = poll(pf, 2, 200);
        if (r <= 0) continue;

        if (pf[1].revents & POLLIN) {
            char msg[64];
            struct sockaddr_in from;
            socklen_t fl = sizeof from;
            ssize_t n = recvfrom(udp, msg, sizeof msg - 1, 0, (struct sockaddr *)&from, &fl);
            if (n > 0) {
                msg[n] = '\0';
                if (strncmp(msg, "MIXTAPE-DS?", 11) == 0) {
                    char reply[64];
                    int rl = snprintf(reply, sizeof reply, "MIXTAPE-DS %d %s", SERVER_PORT, APP_VERSION_STR);
                    sendto(udp, reply, (size_t)rl, 0, (struct sockaddr *)&from, fl);
                }
            }
        }
        if (pf[0].revents & POLLIN) {
            struct sockaddr_in cli;
            socklen_t cl = sizeof cli;
            int fd = accept(tcp, (struct sockaddr *)&cli, &cl);
            if (fd >= 0) {
                handle_client(fd);
                closesocket(fd);
            }
        }
    }
out:
    if (tcp >= 0) closesocket(tcp);
    if (udp >= 0) closesocket(udp);
}

bool server_start(char *err, int errlen) {
    if (started) return true;
    LightLock_Init(&lock);
    memset(&st, 0, sizeof st);
    stopFlag = false;
    changed = false;

    socBuf = memalign(SOC_ALIGN, SOC_SIZE);
    if (!socBuf) { snprintf(err, (size_t)errlen, "out of memory"); return false; }
    if (R_FAILED(socInit(socBuf, SOC_SIZE))) {
        free(socBuf);
        socBuf = NULL;
        snprintf(err, (size_t)errlen, "Wi-Fi isn't available");
        return false;
    }
    struct in_addr ip;
    ip.s_addr = (in_addr_t)gethostid();
    if (ip.s_addr == 0) {
        socExit();
        free(socBuf);
        socBuf = NULL;
        snprintf(err, (size_t)errlen, "not connected to Wi-Fi");
        return false;
    }
    snprintf(st.ip, sizeof st.ip, "%s", inet_ntoa(ip));
    st.running = true;

    s32 prio = 0x30;
    svcGetThreadPriority(&prio, CUR_THREAD_HANDLE);
    thread = threadCreate(server_thread, NULL, 64 * 1024, prio + 1, 2, false);    /* 2nd app core on New 3DS */
    if (!thread) thread = threadCreate(server_thread, NULL, 64 * 1024, prio + 1, -1, false);
    if (!thread) {
        socExit();
        free(socBuf);
        socBuf = NULL;
        snprintf(err, (size_t)errlen, "couldn't start the receiver");
        return false;
    }
    started = true;
    return true;
}

void server_stop(void) {
    if (!started) return;
    stopFlag = true;
    threadJoin(thread, U64_MAX);
    threadFree(thread);
    thread = NULL;
    socExit();
    free(socBuf);
    socBuf = NULL;
    for (int i = 0; i < nnames; i++) free(names[i]);
    nnames = 0;
    started = false;
}
