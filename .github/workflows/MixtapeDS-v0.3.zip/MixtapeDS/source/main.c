/* Mixtape DS v0.2 — a pocket Mixtape for the 3DS.
   Top screen: now playing (cover / cassette / visualiser, or lyrics with ZR).
   Bottom screen: now · ~/library · ~/playlists · settings. */
#include <3ds.h>
#include <citro2d.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "gfx.h"
#include "library.h"
#include "lyrics.h"
#include "player.h"
#include "settings.h"
#include "server.h"

#define APP_VERSION "v0.3"
const char *APP_VERSION_STR = "0.3";
#define MUSIC_DIR   "sdmc:/music"
#define TOP_W  400
#define BOT_W  320
#define SCR_H  240
#define NBARS  60

enum { TAB_NOW = 0, TAB_LIB, TAB_PL };

static Palette P;

/* ---------------- state ---------------- */
static int tab = TAB_NOW;
static bool settingsOpen = false;
static int setFocus = 0;                 /* 0 theme, 1 top screen, 2 lyrics, 3 visualiser, 4 lid, 5 tape stop, 6 receive */
#define SET_ITEMS 7
static bool receiveOpen = false;
static char receiveErr[128] = "";

static int libSel = 0, libTop = 0;
static bool plOpen = false;
static int plSel = 0, plTop = 0, itSel = 0, itTop = 0, plCur = -1;

static int *queue = NULL, qn = 0, *order = NULL, qpos = -1;
static char source[128] = "~/library";
static int curTrack = -1;

static Cover cover;
static Lyrics lyr;
static bool hasLyr = false;
static bool lyricsOn = false;            /* ZR toggle */

static float levels[NBARS];
static float reel = 0.0f;
static bool audioOk = false;

/* touch drag */
static bool touching = false, dragging = false;
static int touchStartX = 0, touchStartY = 0, touchStartTop = 0;

/* ---------------- helpers ---------------- */

static float ty(float rowY, float rowH, float px) { return rowY + (rowH - px * 1.32f) / 2.0f; }

static Track *T(int i) { return (i >= 0 && i < lib.ntracks) ? &lib.tracks[i] : NULL; }

static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static void keep_visible(int *sel, int *top, int n, int rows) {
    if (n <= 0) { *sel = 0; *top = 0; return; }
    *sel = clampi(*sel, 0, n - 1);
    if (*sel < *top) *top = *sel;
    if (*sel >= *top + rows) *top = *sel - rows + 1;
    *top = clampi(*top, 0, n > rows ? n - rows : 0);
}

static bool playing_now(void) { return player_is_open() && !player_is_paused(); }

/* ---------------- queue & playback ---------------- */

static int queue_track(int k) {           /* track index at queue position k (in play order) */
    if (k < 0 || k >= qn || !order) return -1;
    return queue[order[k]];
}

static void build_order(int startIdx) {
    free(order);
    order = malloc(sizeof(int) * (size_t)(qn > 0 ? qn : 1));
    if (!order) { qpos = -1; return; }
    for (int i = 0; i < qn; i++) order[i] = i;
    if (cfg.shuffle && qn > 1) {
        for (int i = qn - 1; i > 0; i--) {
            int j = rand() % (i + 1);
            int t = order[i]; order[i] = order[j]; order[j] = t;
        }
        for (int i = 0; i < qn; i++)
            if (order[i] == startIdx) { order[i] = order[0]; order[0] = startIdx; break; }
        qpos = 0;
    } else {
        qpos = startIdx;
    }
}

static void load_extras(void) {
    Track *t = T(curTrack);
    cover_clear(&cover);
    lyrics_free(&lyr);
    hasLyr = false;
    if (!t) return;

    /* tags from the player are the freshest */
    if (player_title()[0]) { free(t->title); t->title = strdup(player_title()); }
    if (player_artist()[0]) { free(t->artist); t->artist = strdup(player_artist()); }
    if (player_album()[0]) { free(t->album); t->album = strdup(player_album()); }
    if (player_length() > 0) t->secs = (int)player_length();
    t->probed = true;

    size_t n = 0;
    const unsigned char *pic = player_cover(&n);
    if (!(pic && cover_load_bytes(&cover, pic, n))) {
        char dir[512], p[600];
        snprintf(dir, sizeof dir, "%s", t->path);
        char *slash = strrchr(dir, '/');
        if (slash) *slash = '\0';
        const char *names[] = { "cover.jpg", "folder.jpg", "cover.png", "folder.png", "Cover.jpg", "Folder.jpg" };
        for (int i = 0; i < 6 && !cover.ok; i++) {
            snprintf(p, sizeof p, "%s/%s", dir, names[i]);
            cover_load_file(&cover, p);
        }
    }
    hasLyr = lyrics_load(t->path, &lyr);
}

static void play_current(void) {
    for (int attempts = 0; attempts < qn; attempts++) {
        int ti = queue_track(qpos);
        Track *t = T(ti);
        if (!t) break;
        if (player_open(t->path)) {
            curTrack = ti;
            load_extras();
            return;
        }
        if (qpos + 1 >= qn) break;
        qpos++;
    }
    player_stop();
    qpos = -1;
    curTrack = -1;
    cover_clear(&cover);
    lyrics_free(&lyr);
    hasLyr = false;
}

static void start_queue(const int *items, int n, int startIdx, bool shuffleAll, const char *src) {
    if (!audioOk || n <= 0) return;
    free(queue);
    queue = malloc(sizeof(int) * (size_t)n);
    if (!queue) { qn = 0; return; }
    memcpy(queue, items, sizeof(int) * (size_t)n);
    qn = n;
    snprintf(source, sizeof source, "%s", src);
    if (shuffleAll) {
        cfg.shuffle = 1;
        startIdx = rand() % n;
    }
    build_order(clampi(startIdx, 0, n - 1));
    play_current();
}

static void start_library(int idx, bool shuffleAll) {
    int *items = malloc(sizeof(int) * (size_t)(lib.nlib > 0 ? lib.nlib : 1));
    if (!items) return;
    for (int i = 0; i < lib.nlib; i++) items[i] = i;
    start_queue(items, lib.nlib, idx, shuffleAll, "~/library");
    free(items);
}

static void start_playlist(int pl, int idx, bool shuffleAll) {
    if (pl < 0 || pl >= lib.npls) return;
    char src[128];
    snprintf(src, sizeof src, "~/playlists/%s", lib.pls[pl].name);
    start_queue(lib.pls[pl].items, lib.pls[pl].count, idx, shuffleAll, src);
}

static void next_track(bool manual) {
    if (qpos < 0) return;
    if (!manual && cfg.repeat == REP_ONE) { play_current(); return; }
    if (qpos + 1 < qn) { qpos++; play_current(); return; }
    if (cfg.repeat != REP_OFF) {
        if (cfg.shuffle && qn > 1) build_order(rand() % qn);   /* fresh shuffle for the next lap */
        qpos = 0;
        play_current();
        return;
    }
    player_stop();
    qpos = -1;
    curTrack = -1;
    cover_clear(&cover);
    lyrics_free(&lyr);
    hasLyr = false;
}

static void prev_track(void) {
    if (qpos < 0) return;
    if (player_elapsed() > 3.0) { play_current(); return; }
    if (qpos > 0) qpos--;
    else if (cfg.repeat != REP_OFF) qpos = qn - 1;
    play_current();
}

static void toggle_shuffle(void) {
    cfg.shuffle = !cfg.shuffle;
    if (qpos >= 0 && order) build_order(order[qpos]);
    settings_save();
}

static void cycle_repeat(void) {
    cfg.repeat = (cfg.repeat + 1) % REP_COUNT;
    settings_save();
}

static void toggle_pause(void) {
    if (!player_is_open()) {
        if (qn > 0) { if (qpos < 0) qpos = 0; play_current(); }
        else if (lib.nlib > 0) start_library(libSel, false);
        return;
    }
    player_toggle_pause(cfg.tapeStop);
}

static void toggle_lyrics(void) {
    if (cfg.lyrics == LYR_OFF) return;
    lyricsOn = !lyricsOn;
}

static bool lyrics_view(void) {
    if (!player_is_open() || cfg.lyrics == LYR_OFF) return false;
    if (cfg.lyrics == LYR_ALWAYS) return hasLyr && !lyricsOn;     /* ZR hides them in always-on mode */
    return lyricsOn;
}

static void draw_receive(void);
static void open_receive(void);

/* ---------------- top screen pieces ---------------- */

static void draw_status(const char *path) {
    gfx_text(10, 6, 8, P.fog, path, 0, 240);
    u8 lvl = 0, chg = 0;
    PTMU_GetBatteryLevel(&lvl);
    PTMU_GetBatteryChargeState(&chg);
    icon_battery(374, 8, lvl, chg != 0, P.fog, P.text);
    time_t now = time(NULL);
    struct tm *tmv = localtime(&now);
    char clk[16];
    snprintf(clk, sizeof clk, "%02d:%02d", tmv ? tmv->tm_hour : 0, tmv ? tmv->tm_min : 0);
    float w = gfx_text(366, 6, 8, P.fog, clk, T_RIGHT, 0);
    if (cfg.shuffle) gfx_text(366 - w - 8, 6, 8, P.fog, "shf", T_RIGHT, 0);
}

static void draw_progress(void) {
    char a[16], b[16];
    int el = (int)player_elapsed(), len = (int)player_length();
    if (!player_is_open()) { el = 0; len = -1; }
    fmt_secs(el, a, sizeof a);
    fmt_secs(len, b, sizeof b);
    float y = 223;
    float wa = gfx_text(10, y, 8, P.fog, a, 0, 0);
    float wb = gfx_text_width(8, 0, b);
    gfx_text(390, y, 8, P.fog, b, T_RIGHT, 0);
    float x0 = 10 + wa + 8, x1 = 390 - wb - 8;
    gfx_rect(x0, y + 4, x1 - x0, 3, P.gap);
    float p = (len > 0) ? (float)el / (float)len : 0.0f;
    if (p > 1) p = 1;
    gfx_rect(x0, y + 4, (x1 - x0) * p, 3, P.accent);
}

/* bars / dots / wave strip, bottom-aligned at y+h */
static void draw_viz_strip(float x, float y, float w, float h, int n, int style, u32 col) {
    if (style == VIZ_OFF) return;
    float cw = w / n;
    float px = 0, py = 0;
    for (int i = 0; i < n; i++) {
        float lv = levels[(int)((float)i * NBARS / n)];
        float bh = 1.0f + lv * (h - 1);
        float cx = x + i * cw;
        if (style == VIZ_BARS) {
            gfx_rect(cx, y + h - bh, cw - (cw > 4 ? 1 : 0), bh, col);
        } else if (style == VIZ_DOTS) {
            float d = cw * 0.45f < 2 ? 2 : cw * 0.45f;
            gfx_rect(cx + (cw - d) / 2, y + h - bh, d, d, col);
        } else {
            float yy = y + h - bh;
            float xx = cx + cw / 2;
            if (i > 0) gfx_line(px, py, xx, yy, 1.4f, col);
            px = xx; py = yy;
        }
    }
}

static void draw_cover_box(float x, float y, float s) {
    if (cover.ok) { cover_draw(&cover, x, y, s); return; }
    gfx_rrect(x, y, s, s, 3, P.raised);
    /* a little tape where the cover would be */
    float cx = x + s / 2, cy = y + s / 2;
    gfx_rrect(cx - s * 0.28f, cy - s * 0.1f, s * 0.56f, s * 0.2f, s * 0.1f, P.gap);
    C2D_DrawCircleSolid(cx - s * 0.17f, cy, 0.5f, s * 0.06f, P.raised);
    C2D_DrawCircleSolid(cx + s * 0.17f, cy, 0.5f, s * 0.06f, P.raised);
    if (s > 60) gfx_text(cx, y + s - 20, 8, P.fog, "no cover", T_CENTER, 0);
}

static const char *cur_title(void) { Track *t = T(curTrack); return t ? t->title : ""; }
static const char *cur_artist(void) { Track *t = T(curTrack); return t ? t->artist : ""; }

static void draw_top_cover(void) {
    draw_cover_box(10, 28, 128);
    float x = 152, w = 238;
    if (!player_is_open()) {
        gfx_text(x, 32, 8, P.fog, "> nothing playing", 0, w);
        gfx_text(x, 49, 17, P.text, "Mixtape DS", T_BOLD, w);
        gfx_text(x, 72, 10, P.text, lib.nlib ? "pick a song below" : "no music found", 0, w);
        gfx_text(x, 87, 9, P.fog, lib.nlib ? "~/library or ~/playlists" : "put MP3s in sdmc:/music", 0, w);
    } else {
        char buf[300];
        snprintf(buf, sizeof buf, "> playing from %s", source);
        gfx_text(x, 32, 8, P.fog, buf, 0, w);
        gfx_text(x, 49, 17, P.text, cur_title(), T_BOLD, w);
        gfx_text(x, 72, 10, P.text, cur_artist(), 0, w);
        const char *al = player_album(), *yr = player_year();
        if (al[0] && yr[0]) snprintf(buf, sizeof buf, "%s · %s", al, yr);
        else snprintf(buf, sizeof buf, "%s", al[0] ? al : yr);
        gfx_text(x, 87, 9, P.fog, buf, 0, w);
    }
    gfx_rect(x, 127, w, 1, P.gap);
    if (player_is_open() && hasLyr && cfg.lyrics == LYR_ZR) {
        gfx_text(x, 133, 8, P.fog, "lyrics found", 0, w);
        gfx_text(x, 145, 9, P.text, "ZR for full lyrics", T_BOLD, w);
    } else {
        gfx_text(x, 133, 8, P.fog, "next", 0, w);
        int ni = queue_track(qpos + 1);
        if (ni < 0 && cfg.repeat != REP_OFF && qn > 0) ni = queue_track(0);
        Track *n = T(ni);
        if (n && player_is_open()) {
            float tw = gfx_text(x, 145, 9, P.text, n->title, T_BOLD, w * 0.6f);
            char a[200];
            snprintf(a, sizeof a, " · %s", n->artist);
            gfx_text(x + tw, 145, 9, P.fog, a, 0, w - tw);
        } else {
            gfx_text(x, 145, 9, P.fog, "end of queue", 0, w);
        }
    }
    draw_viz_strip(10, 168, 380, 13, NBARS, cfg.viz, P.accent);
}

static void draw_top_cassette(void) {
    float cx = 102, cy = 24, cw = 196, ch = 108;
    u32 body = C2D_Color32(0xED, 0xED, 0xED, 0xFF), white = C2D_Color32(0xFF, 0xFF, 0xFF, 0xFF);
    u32 ink = C2D_Color32(0x11, 0x11, 0x11, 0xFF), tape = C2D_Color32(0x3A, 0x3A, 0x3A, 0xFF);
    u32 grey = C2D_Color32(0x55, 0x55, 0x55, 0xFF), notch = C2D_Color32(0xD6, 0xD6, 0xD6, 0xFF);
    double len = player_length(), el = player_elapsed();
    float p = (len > 0.5) ? (float)(el / len) : 0.0f;
    if (p > 1) p = 1;

    gfx_rrect(cx, cy, cw, ch, 7, body);
    gfx_rrect(cx + 9, cy + 7, 178, 40, 3, white);
    gfx_rect(cx + 9, cy + 7, 178, 3, ink);
    gfx_text(cx + 16, cy + 12, 6, grey, "A", 0, 0);
    gfx_text(cx + 180, cy + 12, 6, grey, "C-60 · mixtape", T_RIGHT, 0);
    gfx_text(cx + 16, cy + 20, 14, ink, player_is_open() ? cur_title() : "Mixtape DS", T_BOLD, 164);
    gfx_text(cx + 16, cy + 36, 7, grey, player_is_open() ? cur_artist() : "side A", 0, 164);

    gfx_rrect(cx + 30, cy + 54, 136, 30, 15, ink);
    gfx_rrect(cx + 64, cy + 64, 68, 10, 2, C2D_Color32(0x2A, 0x2A, 0x2A, 0xFF));
    float lr = 7.5f + 3.5f * (1.0f - p), rr = 7.5f + 3.5f * p;
    float reels[2][2] = { { cx + 47, cy + 69 }, { cx + 149, cy + 69 } };
    float rad[2] = { lr, rr };
    for (int k = 0; k < 2; k++) {
        C2D_DrawCircleSolid(reels[k][0], reels[k][1], 0.5f, rad[k], tape);
        C2D_DrawCircleSolid(reels[k][0], reels[k][1], 0.5f, 5.5f, body);
        for (int s = 0; s < 3; s++) {
            float a = reel + (float)s * 2.0943951f;
            gfx_line(reels[k][0] + cosf(a) * 2.0f, reels[k][1] + sinf(a) * 2.0f,
                     reels[k][0] + cosf(a) * 5.0f, reels[k][1] + sinf(a) * 5.0f, 1.4f, ink);
        }
    }
    gfx_rect(cx + 42, cy + ch - 9, 112, 9, notch);

    gfx_text(200, 141, 14, P.text, player_is_open() ? cur_title() : "nothing playing", T_BOLD | T_CENTER, 380);
    char buf[300];
    snprintf(buf, sizeof buf, "%s · %s", player_is_open() ? cur_artist() : "pick a song", player_is_open() ? source : "below");
    gfx_text(200, 160, 9, P.fog, buf, T_CENTER, 380);
    draw_viz_strip(10, 174, 380, 13, NBARS, cfg.viz, P.accent);
}

static void draw_top_visualiser(void) {
    gfx_text(10, 24, 13, P.text, player_is_open() ? cur_title() : "nothing playing", T_BOLD, 220);
    char buf[300];
    snprintf(buf, sizeof buf, "%s · %s", cur_artist(), source);
    gfx_text(390, 27, 9, P.fog, player_is_open() ? buf : "", T_RIGHT, 160);

    float x = 10, y = 45, w = 380, h = 165;
    gfx_rrect(x, y, w, h, 3, P.gap);
    gfx_rrect(x + 1, y + 1, w - 2, h - 2, 3, P.deep);

    const int cols = 58, rows = 10;
    float gx = x + 8, gy = y + 9, gw = w - 16, cellW = gw / cols, cellH = 13.0f;
    int style = cfg.viz == VIZ_OFF ? VIZ_BARS : cfg.viz;
    for (int c = 0; c < cols; c++) {
        float lv = levels[(int)((float)c * NBARS / cols)];
        float hh = lv * rows;
        float colx = gx + c * cellW;
        if (style == VIZ_BARS) {
            for (int r = 0; r < rows; r++) {
                float fill = hh - r;
                if (fill <= 0) break;
                if (fill > 1) fill = 1;
                u32 col = r >= 6 ? P.accent : (r >= 3 ? P.mid : P.fog);
                float segH = cellH * fill;
                gfx_rect(colx, gy + (rows - r) * cellH - segH, cellW - 1, segH, col);
            }
        } else if (style == VIZ_DOTS) {
            int top = (int)hh;
            for (int r = 0; r <= top && r < rows; r++) {
                u32 col = r >= 6 ? P.accent : (r >= 3 ? P.mid : P.fog);
                gfx_rect(colx + cellW / 2 - 1.5f, gy + (rows - r) * cellH - cellH / 2 - 1.5f, 3, 3, col);
            }
        }
    }
    if (style == VIZ_WAVE) draw_viz_strip(gx, gy, gw, rows * cellH, cols, VIZ_WAVE, P.accent);
    gfx_text(gx, y + h - 17, 7, P.fog, "60", 0, 0);
    gfx_text(gx + gw * 0.25f, y + h - 17, 7, P.fog, "250", T_CENTER, 0);
    gfx_text(gx + gw * 0.5f, y + h - 17, 7, P.fog, "1k", T_CENTER, 0);
    gfx_text(gx + gw * 0.75f, y + h - 17, 7, P.fog, "4k", T_CENTER, 0);
    gfx_text(gx + gw, y + h - 17, 7, P.fog, "14k Hz", T_RIGHT, 0);
}

/* splits text into up to 2 lines that fit maxw */
static int wrap2(const char *s, float px, int flags, float maxw, char *l1, char *l2, size_t n) {
    snprintf(l1, n, "%s", s);
    l2[0] = '\0';
    if (gfx_text_width(px, flags, s) <= maxw) return 1;
    size_t len = strlen(s);
    for (size_t cut = len; cut > 0; cut--) {
        if (s[cut] != ' ') continue;
        char tmp[512];
        size_t k = cut < sizeof tmp - 1 ? cut : sizeof tmp - 1;
        memcpy(tmp, s, k);
        tmp[k] = '\0';
        if (gfx_text_width(px, flags, tmp) <= maxw) {
            snprintf(l1, n, "%s", tmp);
            snprintf(l2, n, "%s", s + cut + 1);
            return 2;
        }
    }
    return 1;
}

static void draw_top_lyrics(void) {
    draw_cover_box(10, 24, 26);
    gfx_text(44, 25, 10, P.text, cur_title(), T_BOLD, 270);
    gfx_text(44, 39, 8, P.fog, cur_artist(), 0, 270);
    gfx_text(390, 33, 7, P.fog, cfg.lyrics == LYR_ALWAYS ? "ZR hide lyrics" : "ZR lyrics off", T_RIGHT, 0);
    gfx_rect(10, 56, 380, 1, P.gap);

    if (!hasLyr) {
        gfx_text(200, 118, 11, P.fog, "no lyrics for this song", T_CENTER, 380);
        char buf[300], base[256];
        snprintf(base, sizeof base, "%s", path_base(T(curTrack) ? T(curTrack)->path : ""));
        char *dot = strrchr(base, '.');
        if (dot) *dot = '\0';
        snprintf(buf, sizeof buf, "put %s.lrc next to the mp3", base);
        gfx_text(200, 136, 8, P.dim, buf, T_CENTER, 380);
        return;
    }

    int ms = (int)(player_elapsed() * 1000.0);
    int cur;
    if (lyr.synced) cur = lyrics_index(&lyr, ms);
    else {
        double len = player_length();
        cur = len > 1 ? (int)(player_elapsed() / len * lyr.n) : 0;
        if (cur >= lyr.n) cur = lyr.n - 1;
    }

    /* five lines around the current one; the current line may wrap to two */
    float sizes[5] = { 10, 11, 15, 11, 10 };
    char l1[512], l2[512];
    int curLines = 1;
    if (cur >= 0 && cur < lyr.n) {
        char withMark[520];
        snprintf(withMark, sizeof withMark, "> %s", lyr.lines[cur].text);
        curLines = wrap2(withMark, 15, T_BOLD, 376, l1, l2, sizeof l1);
    }
    float total = 0;
    for (int k = 0; k < 5; k++) total += sizes[k] * 1.32f * (k == 2 ? curLines : 1);
    total += 4 * 8;
    float y = 57 + (158 - total) / 2;

    for (int k = 0; k < 5; k++) {
        int i = cur - 2 + k;
        float lh = sizes[k] * 1.32f;
        if (i >= 0 && i < lyr.n) {
            if (k == 2) {
                gfx_text(200, y, 15, P.accent, l1, T_BOLD | T_CENTER, 380);
                if (curLines == 2) gfx_text(200, y + lh, 15, P.accent, l2, T_BOLD | T_CENTER, 380);
            } else {
                u32 col = i < cur ? P.dim : (k == 3 ? P.text : P.fog);
                gfx_text(200, y, sizes[k], col, lyr.lines[i].text, T_CENTER, 380);
            }
        } else if (k == 2 && cur < 0 && lyr.n > 0) {
            gfx_text(200, y, 11, P.fog, "· · ·", T_CENTER, 380);
        }
        y += lh * (k == 2 ? curLines : 1) + 8;
    }
}

static void draw_top(void) {
    bool lv = lyrics_view();
    const char *path = "~/now-playing";
    if (lv) path = "~/now-playing · lyrics";
    else if (cfg.topView == VIEW_VISUALISER) path = "~/now-playing · visualiser";
    draw_status(path);
    if (lv) draw_top_lyrics();
    else if (cfg.topView == VIEW_CASSETTE) draw_top_cassette();
    else if (cfg.topView == VIEW_VISUALISER) draw_top_visualiser();
    else draw_top_cover();
    draw_progress();
}

/* ---------------- bottom screen pieces ---------------- */

static void draw_tabs(void) {
    const char *names[3] = { "now", "~/library", "~/playlists" };
    float tw = (BOT_W - 28) / 3.0f;
    for (int i = 0; i < 3; i++) {
        bool on = (i == tab);
        gfx_text(tw * i + tw / 2, ty(0, 21, 9), 9, on ? P.text : P.fog, names[i], T_CENTER | (on ? T_BOLD : 0), tw - 4);
        if (on) gfx_rect(tw * i, 20, tw, 2, P.accent);
    }
    gfx_rect(0, 22, BOT_W, 1, P.gap);
    gfx_rect(BOT_W - 28, 0, 1, 22, P.gap);
    icon_gear(BOT_W - 14, 11, 11, P.fog, P.bg);
}

static void draw_footer(const char *s) {
    gfx_rect(0, 225, BOT_W, 1, P.gap);
    gfx_text(BOT_W / 2, ty(226, 14, 7), 7, P.fog, s, T_CENTER, 312);
}

static void draw_scrollbar(float x, float y, float h, int n, int top, int rows) {
    if (n <= rows) return;
    gfx_rect(x, y, 3, h, P.gap);
    float th = h * rows / n;
    if (th < 10) th = 10;
    float tyy = y + (h - th) * top / (float)(n - rows);
    gfx_rect(x, tyy, 3, th, P.fog);
}

/* title + " · artist" on one line */
static void draw_title_artist(float x, float y, float px, u32 tcol, u32 acol, const char *title, const char *artist, float maxw, bool bold) {
    float w = gfx_text(x, y, px, tcol, title, bold ? T_BOLD : 0, maxw * 0.65f);
    char a[256];
    snprintf(a, sizeof a, " · %s", artist);
    gfx_text(x + w, y, px, acol, a, 0, maxw - w);
}

/* ---- now ---- */
#define NOW_ROW_Y 88
#define NOW_ROW_H 17

static void draw_now(void) {
    float cy = 50;
    icon_shuffle(14, cy - 2, 11, cfg.shuffle ? P.accent : P.fog);
    if (cfg.shuffle) gfx_rect(13, cy + 6, 2, 2, P.accent);
    icon_prev(100, cy, 18, P.text);
    if (playing_now()) icon_pause(160, cy, 28, P.accent);
    else icon_play(160, cy, 28, P.accent);
    icon_next(220, cy, 18, P.text);
    icon_repeat(304, cy - 2, 11, cfg.repeat ? P.accent : P.fog);
    if (cfg.repeat == REP_ONE) gfx_text(311, cy - 9, 6, P.accent, "1", T_BOLD, 0);
    if (cfg.repeat) gfx_rect(303, cy + 6, 2, 2, P.accent);

    gfx_text(10, 76, 8, P.fog, "> up next", 0, 0);
    if (qn > 0 && qpos >= 0) {
        char buf[32];
        snprintf(buf, sizeof buf, "%d / %d", qpos + 1, qn);
        gfx_text(310, 76, 8, P.fog, buf, T_RIGHT, 0);
    }
    int shown = 0;
    for (int k = 1; shown < 5 && qpos >= 0 && k <= qn; k++) {
        int pos = qpos + k;
        if (pos >= qn) {
            if (cfg.repeat == REP_OFF) break;
            pos -= qn;
        }
        Track *t = T(queue_track(pos));
        if (!t) break;
        float y = NOW_ROW_Y + shown * NOW_ROW_H;
        gfx_rect(10, y, 300, 1, P.deep);
        char n[8], len[16];
        snprintf(n, sizeof n, "%02d", pos + 1);
        gfx_text(10, ty(y, NOW_ROW_H, 9), 9, P.fog, n, 0, 0);
        draw_title_artist(32, ty(y, NOW_ROW_H, 9), 9, P.text, P.fog, t->title, t->artist, 240, true);
        fmt_secs(t->secs, len, sizeof len);
        gfx_text(310, ty(y, NOW_ROW_H, 9), 9, P.fog, len, T_RIGHT, 0);
        shown++;
    }
    if (shown == 0) {
        gfx_text(160, 120, 9, P.fog, qn ? "end of the queue" : "nothing queued", T_CENTER, 0);
        gfx_text(160, 136, 8, P.dim, "pick a song in ~/library", T_CENTER, 0);
    }
    draw_footer("Y pause · ←→ skip · SELECT settings · L/R tabs");
}

/* ---- library ---- */
#define LIB_Y    43
#define LIB_ROW  22
#define LIB_ROWS 8

static void draw_track_row(float y, float h, int ti, bool sel, const char *mark, bool twoLine) {
    Track *t = T(ti);
    if (!t) return;
    bool isPlaying = (ti == curTrack) && player_is_open();
    if (sel) gfx_rrect(6, y, 300, h, 3, P.accent);
    u32 fg = sel ? P.ink : P.text, sub = sel ? P.ink : P.fog;
    u32 mk = sel ? P.ink : (isPlaying ? P.accent : P.fog);
    const char *m = isPlaying ? ">" : mark;
    gfx_text(12, ty(y, h, 9), 9, mk, m, T_BOLD, 0);
    char len[16];
    fmt_secs(t->secs, len, sizeof len);
    if (twoLine) {
        gfx_text(26, y + 2, 9, fg, t->title, isPlaying ? T_BOLD : 0, 236);
        gfx_text(26, y + 12.5f, 7, sub, t->artist, 0, 236);
    } else {
        draw_title_artist(32, ty(y, h, 9), 9, fg, sub, t->title, t->artist, 226, isPlaying);
    }
    gfx_text(300, ty(y, h, 8), 8, sub, len, T_RIGHT, 0);
}

static void draw_library(void) {
    char buf[64];
    snprintf(buf, sizeof buf, "%d songs · A–Z", lib.nlib);
    gfx_text(10, 28, 8, P.fog, buf, 0, 0);
    if (lib.nlib > 0) {
        snprintf(buf, sizeof buf, "[ %c ]", first_letter(lib.tracks[libSel].title));
        gfx_text(310, 28, 8, P.fog, buf, T_RIGHT, 0);
    }
    if (lib.nlib == 0) {
        gfx_text(160, 100, 9, P.text, "No MP3s found", T_CENTER, 0);
        gfx_text(160, 118, 8, P.fog, "put them in sdmc:/music/", T_CENTER, 0);
    }
    for (int r = 0; r < LIB_ROWS; r++) {
        int i = libTop + r;
        if (i >= lib.nlib) break;
        draw_track_row(LIB_Y + r * LIB_ROW, LIB_ROW, i, i == libSel, "", true);
    }
    draw_scrollbar(310, LIB_Y + 2, LIB_ROWS * LIB_ROW - 4, lib.nlib, libTop, LIB_ROWS);
    draw_footer("A play · X shuffle all · ←→ letter · L/R tabs");
}

/* ---- playlists ---- */
#define PLL_ROWS 8
#define IT_Y     106
#define IT_ROW   19
#define IT_ROWS  6

static void draw_playlist_list(void) {
    char buf[96];
    snprintf(buf, sizeof buf, "%d playlists", lib.npls);
    gfx_text(10, 28, 8, P.fog, buf, 0, 0);
    if (lib.npls == 0) {
        gfx_text(160, 100, 9, P.text, "No playlists yet", T_CENTER, 0);
        gfx_text(160, 118, 8, P.fog, "add .m3u files to sdmc:/music/", T_CENTER, 0);
    }
    for (int r = 0; r < PLL_ROWS; r++) {
        int i = plTop + r;
        if (i >= lib.npls) break;
        Playlist *p = &lib.pls[i];
        float y = LIB_Y + r * LIB_ROW;
        bool sel = (i == plSel);
        if (sel) gfx_rrect(6, y, 300, LIB_ROW, 3, P.accent);
        u32 fg = sel ? P.ink : P.text, sub = sel ? P.ink : P.fog;
        gfx_text(12, y + 2, 9, fg, p->name, T_BOLD, 270);
        bool all = false;
        int secs = playlist_secs(p, &all);
        if (all && secs > 0) snprintf(buf, sizeof buf, "%d songs · %dh %02dm", p->count, secs / 3600, (secs / 60) % 60);
        else snprintf(buf, sizeof buf, "%d songs", p->count);
        gfx_text(12, y + 12.5f, 7, sub, buf, 0, 270);
        gfx_text(300, ty(y, LIB_ROW, 9), 9, sub, ">", T_RIGHT, 0);
    }
    draw_scrollbar(310, LIB_Y + 2, PLL_ROWS * LIB_ROW - 4, lib.npls, plTop, PLL_ROWS);
    draw_footer("A open · X shuffle play · SELECT settings · L/R tabs");
}

static void draw_mini_tape(float x, float y, const char *name) {
    u32 body = C2D_Color32(0xED, 0xED, 0xED, 0xFF), white = C2D_Color32(0xFF, 0xFF, 0xFF, 0xFF);
    u32 ink = C2D_Color32(0x11, 0x11, 0x11, 0xFF), tape = C2D_Color32(0x3A, 0x3A, 0x3A, 0xFF);
    gfx_rrect(x, y, 92, 58, 5, body);
    gfx_rrect(x + 5, y + 4, 82, 18, 2, white);
    gfx_rect(x + 5, y + 4, 82, 2, ink);
    gfx_text(x + 9, y + 7, 11, ink, name, T_BOLD, 74);
    gfx_rrect(x + 13, y + 28, 66, 16, 8, ink);
    C2D_DrawCircleSolid(x + 21, y + 36, 0.5f, 5.5f, tape);
    C2D_DrawCircleSolid(x + 21, y + 36, 0.5f, 2.5f, body);
    C2D_DrawCircleSolid(x + 71, y + 36, 0.5f, 5.5f, tape);
    C2D_DrawCircleSolid(x + 71, y + 36, 0.5f, 2.5f, body);
    gfx_rect(x + 24, y + 51, 44, 7, C2D_Color32(0xD6, 0xD6, 0xD6, 0xFF));
}

static void draw_playlist_open(void) {
    Playlist *p = &lib.pls[plCur];
    char buf[160];
    snprintf(buf, sizeof buf, "< ~/playlists/%s", p->name);
    gfx_text(10, 29, 8, P.fog, buf, 0, 300);

    draw_mini_tape(10, 42, p->name);
    bool all = false;
    int secs = playlist_secs(p, &all);
    if (all && secs > 0) snprintf(buf, sizeof buf, "%d songs · %dh %02dm", p->count, secs / 3600, (secs / 60) % 60);
    else snprintf(buf, sizeof buf, "%d songs", p->count);
    gfx_text(111, 50, 8, P.fog, buf, 0, 200);
    gfx_rrect(111, 66, 58, 22, 3, P.accent);
    icon_play(125, 77, 10, P.ink);
    gfx_text(134, ty(66, 22, 9), 9, P.ink, "play", T_BOLD, 0);
    gfx_rrect(175, 66, 62, 22, 3, P.gap);
    gfx_rrect(176, 67, 60, 20, 3, P.raised);
    gfx_text(206, ty(66, 22, 9), 9, P.text, "shuffle", T_CENTER, 0);

    if (p->count == 0) gfx_text(160, 140, 8, P.fog, "none of these songs are in sdmc:/music", T_CENTER, 300);
    for (int r = 0; r < IT_ROWS; r++) {
        int i = itTop + r;
        if (i >= p->count) break;
        char n[8];
        snprintf(n, sizeof n, "%02d", i + 1);
        draw_track_row(IT_Y + r * IT_ROW, IT_ROW, p->items[i], i == itSel, n, false);
    }
    draw_scrollbar(310, IT_Y + 2, IT_ROWS * IT_ROW - 4, p->count, itTop, IT_ROWS);
    draw_footer("A play from here · B back · X shuffle");
}

/* ---- settings ---- */
static const char *VIEW_NAMES[VIEW_COUNT] = { "cover", "cassette", "visualiser" };
static const char *LYR_NAMES[LYR_COUNT] = { "ZR to show", "always on", "off" };
static const char *VIZ_NAMES[VIZ_COUNT] = { "bars", "dots", "wave", "off" };
static const char *LID_NAMES[LID_COUNT] = { "keep playing", "pause" };

#define SW_Y 42
#define TOP_Y 97
#define LYR_Y 134
#define ROWS_Y 159
#define ROW_STEP 16

static float chip_w(const char *s) { return gfx_text_width(8, T_BOLD, s) + 14; }

static void draw_chips(float y, const char **names, int n, int active) {
    float x = 10;
    for (int i = 0; i < n; i++) {
        float w = chip_w(names[i]);
        if (i == active) {
            gfx_rrect(x, y, w, 18, 3, P.accent);
            gfx_text(x + w / 2, ty(y, 18, 8), 8, P.ink, names[i], T_BOLD | T_CENTER, 0);
        } else {
            gfx_rrect(x, y, w, 18, 3, P.gap);
            gfx_rrect(x + 1, y + 1, w - 2, 16, 3, P.raised);
            gfx_text(x + w / 2, ty(y, 18, 8), 8, P.text, names[i], T_CENTER, 0);
        }
        x += w + 4;
    }
}

static void section_label(float y, const char *name, int idx) {
    bool f = (setFocus == idx);
    float w = gfx_text(10, y, 8, f ? P.accent : P.fog, ">", T_BOLD, 0);
    gfx_text(10 + w + 5, y, 8, f ? P.text : P.fog, name, f ? T_BOLD : 0, 0);
}

static void draw_settings(void) {
    gfx_text(10, ty(0, 22, 9), 9, P.text, "~/settings", T_BOLD, 0);
    gfx_text(310, ty(0, 22, 8), 8, P.fog, "SELECT to close", T_RIGHT, 0);
    gfx_rect(0, 22, BOT_W, 1, P.gap);

    section_label(30, "theme", 0);
    float sw = (300 - 15) / 4.0f;
    for (int i = 0; i < THEME_COUNT; i++) {
        float x = 10 + i * (sw + 5);
        u32 bg, text, acc;
        theme_colors(i, &bg, &text, &acc);
        if (i == cfg.theme) gfx_rrect(x, SW_Y, sw, 36, 3, P.accent);
        else gfx_rrect(x, SW_Y, sw, 36, 3, P.gap);
        float b = (i == cfg.theme) ? 2 : 1;
        gfx_rrect(x + b, SW_Y + b, sw - 2 * b, 36 - 2 * b, 2, bg);
        gfx_rect(x + 5, SW_Y + 4, 18, 5, acc);
        gfx_text(x + 5, SW_Y + 23, 7, text, THEME_NAMES[i], T_BOLD, sw - 8);
    }

    section_label(85, "top screen", 1);
    draw_chips(TOP_Y, VIEW_NAMES, VIEW_COUNT, cfg.topView);
    section_label(122, "lyrics", 2);
    draw_chips(LYR_Y, LYR_NAMES, LYR_COUNT, cfg.lyrics);

    gfx_rect(10, ROWS_Y, 300, 1, P.gap);
    const char *labels[4] = { "visualiser", "lid closed", "tape stop on pause", "receive from phone" };
    char vals[4][32];
    snprintf(vals[0], 32, "[ %s ]", VIZ_NAMES[cfg.viz]);
    snprintf(vals[1], 32, "[ %s ]", LID_NAMES[cfg.lid]);
    snprintf(vals[2], 32, "[ %s ]", cfg.tapeStop ? "on" : "off");
    snprintf(vals[3], 32, "[ open ]");
    bool lit[4] = { cfg.viz != VIZ_OFF, true, cfg.tapeStop != 0, true };
    for (int r = 0; r < 4; r++) {
        float y = ROWS_Y + 1 + r * ROW_STEP;
        bool f = (setFocus == 3 + r);
        if (f) gfx_rect(6, y, 308, ROW_STEP, P.raised);
        gfx_text(10, ty(y, ROW_STEP, 9), 9, P.text, labels[r], f ? T_BOLD : 0, 0);
        gfx_text(310, ty(y, ROW_STEP, 9), 9, lit[r] ? P.accent : P.fog, vals[r], T_BOLD, 0);
        if (r < 3) gfx_rect(10, y + ROW_STEP - 0.5f, 300, 0.5f, P.deep);
    }
    char buf[96];
    snprintf(buf, sizeof buf, "Mixtape DS %s · %d songs · %d playlists", APP_VERSION, lib.nlib, lib.npls);
    draw_footer(buf);
}

static void draw_bottom(void) {
    if (receiveOpen) { draw_receive(); return; }
    if (settingsOpen) { draw_settings(); return; }
    draw_tabs();
    if (tab == TAB_NOW) draw_now();
    else if (tab == TAB_LIB) draw_library();
    else if (plOpen && plCur >= 0) draw_playlist_open();
    else draw_playlist_list();
    if (!audioOk) {
        gfx_rect(0, 211, BOT_W, 14, P.raised);
        gfx_text(160, ty(211, 14, 7), 7, P.accent, "audio failed to start (needs sdmc:/3ds/dspfirm.cdc)", T_CENTER, 312);
    }
}

/* ---------------- receive from phone ---------------- */

/* Reloads the library after new files arrived, keeping the queue and the playing song. */
static void rescan_library(void) {
    char **qpaths = NULL;
    char *curPath = NULL;
    if (qn > 0) {
        qpaths = calloc((size_t)qn, sizeof(char *));
        for (int i = 0; qpaths && i < qn; i++) { Track *t = T(queue[i]); qpaths[i] = strdup(t ? t->path : ""); }
    }
    if (T(curTrack)) curPath = strdup(T(curTrack)->path);

    library_save_cache();
    library_free();
    library_load(MUSIC_DIR);

    for (int i = 0; qpaths && i < qn; i++) {
        int found = 0;
        for (int k = 0; k < lib.ntracks; k++)
            if (strcmp(lib.tracks[k].path, qpaths[i]) == 0) { found = k; break; }
        queue[i] = found;
        free(qpaths[i]);
    }
    free(qpaths);
    curTrack = -1;
    if (curPath) {
        for (int k = 0; k < lib.ntracks; k++)
            if (strcmp(lib.tracks[k].path, curPath) == 0) { curTrack = k; break; }
        free(curPath);
    }
    plOpen = false;
    plSel = clampi(plSel, 0, lib.npls > 0 ? lib.npls - 1 : 0);
    keep_visible(&libSel, &libTop, lib.nlib, LIB_ROWS);
}

static void open_receive(void) {
    receiveErr[0] = '\0';
    if (!server_start(receiveErr, sizeof receiveErr)) {
        if (!receiveErr[0]) snprintf(receiveErr, sizeof receiveErr, "couldn't start");
    }
    receiveOpen = true;
}

static void close_receive(void) {
    if (server_running()) server_stop();
    receiveOpen = false;
    if (server_take_changed()) rescan_library();
}

static void draw_receive(void) {
    ServerStatus s;
    server_status(&s);
    gfx_text(10, ty(0, 22, 9), 9, P.text, "~/receive", T_BOLD, 0);
    gfx_text(310, ty(0, 22, 8), 8, P.fog, "B to finish", T_RIGHT, 0);
    gfx_rect(0, 22, BOT_W, 1, P.gap);

    if (!s.running) {
        gfx_text(160, 70, 11, P.text, "Wi-Fi isn't ready", T_BOLD | T_CENTER, 300);
        gfx_text(160, 92, 8, P.fog, receiveErr, T_CENTER, 300);
        gfx_text(160, 110, 8, P.dim, "turn on Wi-Fi and connect to the same network as your phone", T_CENTER, 300);
        draw_footer("B back");
        return;
    }

    gfx_text(10, 32, 8, P.fog, "> this 3DS", 0, 0);
    char addr[64];
    snprintf(addr, sizeof addr, "%s:%d", s.ip, SERVER_PORT);
    gfx_rrect(10, 44, 300, 34, 3, P.gap);
    gfx_rrect(11, 45, 298, 32, 3, P.raised);
    gfx_text(160, ty(44, 34, 15), 15, P.accent, addr, T_BOLD | T_CENTER, 290);

    gfx_text(10, 88, 8, P.fog, "> on your phone", 0, 0);
    gfx_text(10, 100, 8, P.text, "Mixtape: playlist > send to 3DS", 0, 300);
    gfx_text(10, 112, 8, P.text, "or open the address above in a browser", 0, 300);

    gfx_rect(10, 130, 300, 1, P.gap);
    if (s.current[0]) {
        gfx_text(10, 138, 8, P.fog, "receiving", 0, 0);
        gfx_text(10, 150, 9, P.text, s.current, T_BOLD, 300);
        float p = s.total > 0 ? (float)((double)s.done / (double)s.total) : 0.0f;
        gfx_rect(10, 166, 300, 3, P.gap);
        gfx_rect(10, 166, 300 * p, 3, P.accent);
        char pct[48];
        snprintf(pct, sizeof pct, "%.1f / %.1f MB", s.done / 1048576.0, s.total / 1048576.0);
        gfx_text(310, 174, 7, P.fog, pct, T_RIGHT, 0);
    } else {
        gfx_text(10, 138, 8, P.fog, s.phoneSeen ? "connected" : "waiting for your phone ...", 0, 0);
        if (s.last[0]) {
            gfx_text(10, 150, 8, P.fog, "last:", 0, 0);
            gfx_text(42, 150, 8, P.text, s.last, 0, 268);
        }
    }
    char cnt[64];
    snprintf(cnt, sizeof cnt, "%d file%s received", s.received, s.received == 1 ? "" : "s");
    gfx_text(10, 194, 9, s.received ? P.accent : P.fog, cnt, T_BOLD, 0);
    if (s.error[0]) gfx_text(310, 196, 7, P.fog, s.error, T_RIGHT, 180);
    draw_footer("keep this screen open while sending · B to finish");
}

/* ---------------- settings input ---------------- */

static void settings_change(int dir) {
    switch (setFocus) {
        case 0: cfg.theme = (cfg.theme + dir + THEME_COUNT) % THEME_COUNT; P = palette_make(cfg.theme); break;
        case 1: cfg.topView = (cfg.topView + dir + VIEW_COUNT) % VIEW_COUNT; break;
        case 2: cfg.lyrics = (cfg.lyrics + dir + LYR_COUNT) % LYR_COUNT; lyricsOn = false; break;
        case 3: cfg.viz = (cfg.viz + dir + VIZ_COUNT) % VIZ_COUNT; break;
        case 4: cfg.lid = (cfg.lid + dir + LID_COUNT) % LID_COUNT; break;
        case 5: cfg.tapeStop = !cfg.tapeStop; break;
        case 6: if (dir > 0) open_receive(); return;
    }
    settings_save();
}

static int chip_hit(float x, const char **names, int n) {
    float cx = 10;
    for (int i = 0; i < n; i++) {
        float w = chip_w(names[i]);
        if (x >= cx && x < cx + w + 4) return i;
        cx += w + 4;
    }
    return -1;
}

static void settings_touch(int x, int y) {
    if (y < 23) { settingsOpen = false; return; }
    if (y >= SW_Y && y < SW_Y + 36) {
        int i = (int)((x - 10) / ((300 - 15) / 4.0f + 5));
        if (i >= 0 && i < THEME_COUNT) { setFocus = 0; cfg.theme = i; P = palette_make(i); settings_save(); }
    } else if (y >= TOP_Y - 2 && y < TOP_Y + 20) {
        int i = chip_hit(x, VIEW_NAMES, VIEW_COUNT);
        if (i >= 0) { setFocus = 1; cfg.topView = i; settings_save(); }
    } else if (y >= LYR_Y - 2 && y < LYR_Y + 20) {
        int i = chip_hit(x, LYR_NAMES, LYR_COUNT);
        if (i >= 0) { setFocus = 2; cfg.lyrics = i; lyricsOn = false; settings_save(); }
    } else if (y >= ROWS_Y && y < ROWS_Y + 4 * ROW_STEP) {
        setFocus = 3 + (y - ROWS_Y) / ROW_STEP;
        settings_change(1);
    }
}

/* ---------------- list input ---------------- */

static void jump_letter(int dir) {
    if (lib.nlib == 0) return;
    char cur = first_letter(lib.tracks[libSel].title);
    int i = libSel;
    if (dir > 0) {
        while (i < lib.nlib && first_letter(lib.tracks[i].title) == cur) i++;
        if (i >= lib.nlib) i = lib.nlib - 1;
    } else {
        while (i > 0 && first_letter(lib.tracks[i - 1].title) == cur) i--;   /* start of this letter */
        if (i == libSel && i > 0) {                                           /* already there: previous letter */
            char prev = first_letter(lib.tracks[i - 1].title);
            i--;
            while (i > 0 && first_letter(lib.tracks[i - 1].title) == prev) i--;
        }
    }
    libSel = i;
    libTop = libSel;
    keep_visible(&libSel, &libTop, lib.nlib, LIB_ROWS);
}

/* rows: list geometry for the current tab, for touch + drag */
static bool list_geom(int *y0, int *rowH, int *rows, int *n, int **sel, int **top) {
    if (tab == TAB_LIB) { *y0 = LIB_Y; *rowH = LIB_ROW; *rows = LIB_ROWS; *n = lib.nlib; *sel = &libSel; *top = &libTop; return true; }
    if (tab == TAB_PL && !plOpen) { *y0 = LIB_Y; *rowH = LIB_ROW; *rows = PLL_ROWS; *n = lib.npls; *sel = &plSel; *top = &plTop; return true; }
    if (tab == TAB_PL && plOpen && plCur >= 0) { *y0 = IT_Y; *rowH = IT_ROW; *rows = IT_ROWS; *n = lib.pls[plCur].count; *sel = &itSel; *top = &itTop; return true; }
    return false;
}

static void activate_list(bool shuffleAll) {
    if (tab == TAB_LIB) {
        if (lib.nlib) start_library(libSel, shuffleAll);
    } else if (tab == TAB_PL && !plOpen) {
        if (lib.npls == 0) return;
        if (shuffleAll) { start_playlist(plSel, 0, true); return; }
        plOpen = true;
        plCur = plSel;
        itSel = itTop = 0;
    } else if (tab == TAB_PL && plOpen) {
        start_playlist(plCur, itSel, shuffleAll);
    }
}

static void bottom_tap(int x, int y) {
    if (y < 23) {
        if (x >= BOT_W - 28) { settingsOpen = true; return; }
        int t = (int)(x / ((BOT_W - 28) / 3.0f));
        tab = clampi(t, 0, 2);
        return;
    }
    if (tab == TAB_NOW) {
        if (y >= 30 && y < 72) {
            if (x < 40) toggle_shuffle();
            else if (x >= 78 && x < 122) prev_track();
            else if (x >= 134 && x < 186) toggle_pause();
            else if (x >= 198 && x < 242) next_track(true);
            else if (x >= 280) cycle_repeat();
        } else if (y >= NOW_ROW_Y && y < NOW_ROW_Y + 5 * NOW_ROW_H && qpos >= 0) {
            int k = 1 + (y - NOW_ROW_Y) / NOW_ROW_H;
            int pos = qpos + k;
            if (pos >= qn) { if (cfg.repeat == REP_OFF) return; pos -= qn; }
            if (pos >= 0 && pos < qn) { qpos = pos; play_current(); }
        }
        return;
    }
    if (tab == TAB_PL && plOpen) {
        if (y < 41) { plOpen = false; return; }
        if (y >= 66 && y < 88) {
            if (x >= 111 && x < 169) { start_playlist(plCur, 0, false); return; }
            if (x >= 175 && x < 237) { start_playlist(plCur, 0, true); return; }
        }
    }
    int y0, rowH, rows, n, *sel, *top;
    if (!list_geom(&y0, &rowH, &rows, &n, &sel, &top)) return;
    if (y < y0 || y >= y0 + rows * rowH) return;
    int i = *top + (y - y0) / rowH;
    if (i >= n) return;
    if (i == *sel) activate_list(false);
    else *sel = i;
}

/* ---------------- main ---------------- */

int main(void) {
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS * 2);
    C2D_Prepare();
    C3D_RenderTarget *top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget *bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    ptmuInit();
    gspLcdInit();
    gfx_init();
    srand((unsigned)osGetTime());
    hidSetRepeatParameters(18, 4);

    settings_load();
    P = palette_make(cfg.theme);
    memset(&cover, 0, sizeof cover);
    memset(&lyr, 0, sizeof lyr);

    /* first frame: "loading" while the SD card is scanned */
    gfx_frame_begin();
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
    C2D_TargetClear(top, P.bg);
    C2D_SceneBegin(top);
    gfx_text(200, 110, 14, P.text, "Mixtape DS", T_BOLD | T_CENTER, 0);
    gfx_text(200, 132, 8, P.fog, "reading sdmc:/music ...", T_CENTER, 0);
    C2D_TargetClear(bot, P.bg);
    C3D_FrameEnd(0);

    library_load(MUSIC_DIR);
    audioOk = player_init();

    u8 lastShell = 1;
    bool sleepAllowed = true, pausedByLid = false;
    int frame = 0;

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown(), kRep = hidKeysDownRepeat(), kHeld = hidKeysHeld();
        if (kDown & KEY_START) break;

        if (receiveOpen) {
            if (kDown & (KEY_B | KEY_SELECT)) close_receive();
            kDown &= ~(KEY_SELECT | KEY_B | KEY_A | KEY_X | KEY_L | KEY_R | KEY_UP | KEY_DOWN | KEY_LEFT | KEY_RIGHT | KEY_TOUCH);
            kRep = 0;
            kHeld &= ~KEY_TOUCH;
        }
        if (kDown & KEY_SELECT) settingsOpen = !settingsOpen;
        if (kDown & KEY_ZR) toggle_lyrics();
        if (kDown & KEY_Y) toggle_pause();

        if (settingsOpen) {
            if (kRep & KEY_UP) setFocus = (setFocus + SET_ITEMS - 1) % SET_ITEMS;
            if (kRep & KEY_DOWN) setFocus = (setFocus + 1) % SET_ITEMS;
            if (kRep & KEY_LEFT) settings_change(-1);
            if (kRep & KEY_RIGHT) settings_change(1);
            if (kDown & KEY_A) settings_change(1);
            if (kDown & KEY_B) settingsOpen = false;
        } else {
            if (kDown & KEY_L) tab = (tab + 2) % 3;
            if (kDown & KEY_R) tab = (tab + 1) % 3;

            if (tab == TAB_NOW) {
                if (kDown & KEY_LEFT) prev_track();
                if (kDown & KEY_RIGHT) next_track(true);
                if (kDown & KEY_A) toggle_pause();
                if (kDown & KEY_X) toggle_shuffle();
                if (kDown & KEY_B) toggle_lyrics();
            } else {
                int y0, rowH, rows, n, *sel, *top_;
                if (list_geom(&y0, &rowH, &rows, &n, &sel, &top_)) {
                    if (kRep & KEY_UP) { (*sel)--; keep_visible(sel, top_, n, rows); }
                    if (kRep & KEY_DOWN) { (*sel)++; keep_visible(sel, top_, n, rows); }
                    if (tab == TAB_LIB) {
                        if (kRep & KEY_LEFT) jump_letter(-1);
                        if (kRep & KEY_RIGHT) jump_letter(1);
                    } else {
                        if (kRep & KEY_LEFT) { *sel -= rows; keep_visible(sel, top_, n, rows); }
                        if (kRep & KEY_RIGHT) { *sel += rows; keep_visible(sel, top_, n, rows); }
                    }
                }
                if (kDown & KEY_A) activate_list(false);
                if (kDown & KEY_X) activate_list(true);
                if ((kDown & KEY_B) && tab == TAB_PL && plOpen) plOpen = false;
            }
        }

        /* touch: tap to pick, drag to scroll lists */
        if (kHeld & KEY_TOUCH) {
            touchPosition tp;
            hidTouchRead(&tp);
            int y0, rowH, rows, n, *sel, *top_;
            bool isList = !settingsOpen && list_geom(&y0, &rowH, &rows, &n, &sel, &top_);
            if (kDown & KEY_TOUCH) {
                touching = true;
                dragging = false;
                touchStartX = tp.px;
                touchStartY = tp.py;
                touchStartTop = isList ? *top_ : 0;
            } else if (touching && isList && touchStartY >= y0) {
                int dy = tp.py - touchStartY;
                if (abs(dy) > 8) dragging = true;
                if (dragging && n > rows) {
                    *top_ = clampi(touchStartTop - dy / rowH, 0, n - rows);
                    if (*sel < *top_) *sel = *top_;
                    if (*sel >= *top_ + rows) *sel = *top_ + rows - 1;
                }
            }
        } else if (touching) {
            /* released: a tap unless it turned into a drag */
            touching = false;
            if (!dragging) {
                if (settingsOpen) settings_touch(touchStartX, touchStartY);
                else bottom_tap(touchStartX, touchStartY);
            }
        }

        /* audio */
        player_update();
        if (player_finished()) next_track(false);

        /* lid */
        u8 shell = 1;
        PTMU_GetShellState(&shell);
        if (shell != lastShell) {
            if (shell == 0) {
                if (cfg.lid == LID_PAUSE && playing_now()) { player_set_paused(true, false); pausedByLid = true; }
                GSPLCD_PowerOffBacklight(GSPLCD_SCREEN_BOTH);
            } else {
                GSPLCD_PowerOnBacklight(GSPLCD_SCREEN_BOTH);
                if (pausedByLid) { player_set_paused(false, false); pausedByLid = false; }
            }
            lastShell = shell;
        }
        bool pn = playing_now();
        bool busy = pn || receiveOpen;
        if (sleepAllowed == busy) {
            sleepAllowed = !busy;
            aptSetSleepAllowed(sleepAllowed);
        }

        /* fill in tags + lengths: visible rows first, then the rest slowly */
        frame++;
        {
            int y0, rowH, rows, n, *sel, *top_;
            int want = -1;
            if (!settingsOpen && list_geom(&y0, &rowH, &rows, &n, &sel, &top_) && !(tab == TAB_PL && !plOpen)) {
                for (int r = 0; r < rows && *top_ + r < n; r++) {
                    int ti = (tab == TAB_LIB) ? *top_ + r : lib.pls[plCur].items[*top_ + r];
                    if (!lib.tracks[ti].probed) { want = ti; break; }
                }
            } else if (!settingsOpen && tab == TAB_NOW && qpos >= 0) {
                for (int k = 1; k <= 5 && qpos + k < qn; k++) {
                    int ti = queue_track(qpos + k);
                    if (ti >= 0 && !lib.tracks[ti].probed) { want = ti; break; }
                }
            }
            if (want >= 0) library_probe(want);
            else if (frame % 4 == 0) library_probe_some(libTop, 1);
        }

        /* visualiser */
        float raw[NBARS];
        player_levels(raw, NBARS);
        for (int i = 0; i < NBARS; i++)
            levels[i] = raw[i] > levels[i] ? raw[i] : levels[i] * 0.86f + raw[i] * 0.14f;
        if (pn) reel += 0.07f;

        gfx_frame_begin();
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(top, P.bg);
        C2D_SceneBegin(top);
        draw_top();
        C2D_TargetClear(bot, P.bg);
        C2D_SceneBegin(bot);
        draw_bottom();
        C3D_FrameEnd(0);
    }

    if (server_running()) server_stop();
    settings_save();
    library_save_cache();
    GSPLCD_PowerOnBacklight(GSPLCD_SCREEN_BOTH);
    aptSetSleepAllowed(true);
    player_exit();
    cover_clear(&cover);
    lyrics_free(&lyr);
    library_free();
    free(queue);
    free(order);
    gfx_exit();
    gspLcdExit();
    ptmuExit();
    C2D_Fini();
    C3D_Fini();
    gfxExit();
    return 0;
}
