/* Mixtape DS v0.1 — a pocket Mixtape for the 3DS.
   Top screen: now playing. Bottom screen: library and playlists. */
#include <3ds.h>
#include <citro2d.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "library.h"
#include "player.h"

#define APP_VERSION "v0.1"
#define MUSIC_DIR   "sdmc:/music"
#define TOP_W  400
#define BOT_W  320
#define SCR_H  240
#define ROWS   8
#define ROW_H  20
#define LIST_Y 48
#define BARS   32

enum { VIEW_LIB = 0, VIEW_PLAYLISTS = 1, VIEW_PL_TRACKS = 2 };

static C2D_TextBuf g_tb;
static u32 cBg, cPanel, cDark, cAccent, cText, cMuted, cDim, cTape, cInk;

static TrackList lib, plTracks, queue;
static Playlist pls[MAX_PLAYLISTS];
static int plCount = 0;
static int tab = 0;               /* 0 library, 1 playlists */
static bool inPlaylist = false;
static int openPl = -1;
static int sel[3], topRow[3];

static int *order = NULL;
static int qpos = -1;
static bool shuffle = false;
static bool audioOk = false;

static float levels[BARS];
static float reelAngle = 0.0f;

/* ---------- text helpers ---------- */

static void text(float x, float y, float s, u32 col, const char *str, u32 flags) {
    if (!str || !*str) return;
    C2D_Text t;
    C2D_TextParse(&t, g_tb, str);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor | flags, x, y, 0.5f, s, s, col);
}

static void text_fit(float x, float y, float s, u32 col, const char *str, float maxw, u32 flags) {
    if (!str || !*str) return;
    C2D_Text t;
    C2D_TextParse(&t, g_tb, str);
    float w = 0.0f, h = 0.0f;
    C2D_TextGetDimensions(&t, s, s, &w, &h);
    if (w <= maxw) {
        C2D_TextOptimize(&t);
        C2D_DrawText(&t, C2D_WithColor | flags, x, y, 0.5f, s, s, col);
        return;
    }
    char buf[256];
    int len = (int)strlen(str);
    int cut = (int)((float)len * (maxw / w)) - 3;
    if (cut > (int)sizeof(buf) - 4) cut = (int)sizeof(buf) - 4;
    if (cut < 1) cut = 1;
    while (cut > 1 && (((unsigned char)str[cut]) & 0xC0) == 0x80) cut--;
    memcpy(buf, str, (size_t)cut);
    strcpy(buf + cut, "...");
    text(x, y, s, col, buf, flags);
}

static void fmt_time(double secs, char *out, size_t n) {
    if (secs < 0) secs = 0;
    int t = (int)secs;
    snprintf(out, n, "%d:%02d", t / 60, t % 60);
}

/* ---------- queue ---------- */

static const char *current_path(void) {
    if (qpos < 0 || qpos >= queue.count || !order) return NULL;
    return queue.paths[order[qpos]];
}

static void build_order(int startIdx) {
    free(order);
    order = malloc(sizeof(int) * (size_t)(queue.count > 0 ? queue.count : 1));
    if (!order) { qpos = -1; return; }
    for (int i = 0; i < queue.count; i++) order[i] = i;
    if (shuffle && queue.count > 1) {
        for (int i = queue.count - 1; i > 0; i--) {
            int j = rand() % (i + 1);
            int tmp = order[i]; order[i] = order[j]; order[j] = tmp;
        }
        for (int i = 0; i < queue.count; i++)
            if (order[i] == startIdx) { order[i] = order[0]; order[0] = startIdx; break; }
        qpos = 0;
    } else {
        qpos = startIdx;
    }
}

static void play_current(void) {
    for (int attempts = 0; attempts < queue.count; attempts++) {
        const char *p = current_path();
        if (!p) break;
        if (player_open(p)) return;
        if (qpos + 1 >= queue.count) break;
        qpos++;                                   /* unreadable file: skip it */
    }
    player_stop();
    qpos = -1;
}

static void start_queue(const TrackList *src, int idx) {
    if (!audioOk || src->count == 0) return;
    tl_free(&queue);
    tl_copy(&queue, src);
    if (idx < 0 || idx >= queue.count) idx = 0;
    build_order(idx);
    play_current();
}

static void next_track(void) {
    if (qpos < 0) return;
    if (qpos + 1 < queue.count) { qpos++; play_current(); }
    else { player_stop(); qpos = -1; }
}

static void prev_track(void) {
    if (qpos < 0) return;
    if (player_elapsed() > 3.0 || qpos == 0) play_current();
    else { qpos--; play_current(); }
}

static void toggle_shuffle(void) {
    shuffle = !shuffle;
    if (qpos >= 0 && order) {
        int cur = order[qpos];
        build_order(cur);
    }
}

/* ---------- views ---------- */

static int view(void) {
    if (tab == 0) return VIEW_LIB;
    return inPlaylist ? VIEW_PL_TRACKS : VIEW_PLAYLISTS;
}

static int view_count(int v) {
    if (v == VIEW_LIB) return lib.count;
    if (v == VIEW_PLAYLISTS) return plCount;
    return plTracks.count;
}

static void clamp_view(int v) {
    int n = view_count(v);
    if (sel[v] >= n) sel[v] = n - 1;
    if (sel[v] < 0) sel[v] = 0;
    if (sel[v] < topRow[v]) topRow[v] = sel[v];
    if (sel[v] >= topRow[v] + ROWS) topRow[v] = sel[v] - ROWS + 1;
    if (topRow[v] < 0) topRow[v] = 0;
}

static void activate(void) {
    int v = view();
    if (view_count(v) == 0) return;
    if (v == VIEW_LIB) {
        start_queue(&lib, sel[v]);
    } else if (v == VIEW_PLAYLISTS) {
        tl_free(&plTracks);
        playlist_load(pls[sel[v]].path, &lib, &plTracks);
        openPl = sel[v];
        inPlaylist = true;
        sel[VIEW_PL_TRACKS] = 0;
        topRow[VIEW_PL_TRACKS] = 0;
    } else {
        start_queue(&plTracks, sel[v]);
    }
}

/* ---------- drawing ---------- */

static void draw_battery(float x, float y) {
    u8 level = 0;
    PTMU_GetBatteryLevel(&level);           /* 0..5 */
    C2D_DrawRectSolid(x, y, 0.5f, 22, 11, cMuted);
    C2D_DrawRectSolid(x + 1, y + 1, 0.5f, 20, 9, cBg);
    C2D_DrawRectSolid(x + 22, y + 3, 0.5f, 2, 5, cMuted);
    float w = 18.0f * (float)(level > 5 ? 5 : level) / 5.0f;
    if (w > 0) C2D_DrawRectSolid(x + 2, y + 2, 0.5f, w, 7, level <= 1 ? cAccent : cText);
}

static void draw_reel(float cx, float cy, float tapeR, float angle) {
    C2D_DrawCircleSolid(cx, cy, 0.5f, tapeR, cTape);
    C2D_DrawCircleSolid(cx, cy, 0.5f, 8.0f, cAccent);
    C2D_DrawCircleSolid(cx, cy, 0.5f, 2.5f, cDark);
    for (int k = 0; k < 3; k++) {
        float a = angle + (float)k * 2.0943951f;
        C2D_DrawCircleSolid(cx + cosf(a) * 5.2f, cy + sinf(a) * 5.2f, 0.5f, 1.6f, cDark);
    }
}

static void draw_top(void) {
    char buf[300], t1[16], t2[16];

    text(12, 6, 0.5f, cAccent, "MIXTAPE DS", 0);
    time_t now = time(NULL);
    struct tm *tmv = localtime(&now);
    snprintf(buf, sizeof buf, "%s%02d:%02d", shuffle ? "SHF   " : "", tmv ? tmv->tm_hour : 0, tmv ? tmv->tm_min : 0);
    text(TOP_W - 42, 6, 0.5f, cMuted, buf, C2D_AlignRight);
    draw_battery(TOP_W - 34, 10);

    /* cassette */
    float cx = 100, cy = 30, cw = 200, ch = 104;
    double len = player_length(), el = player_elapsed();
    float p = (len > 0.5) ? (float)(el / len) : 0.0f;
    if (p > 1.0f) p = 1.0f;

    C2D_DrawRectSolid(cx, cy, 0.5f, cw, ch, cAccent);
    C2D_DrawRectSolid(cx + 3, cy + 3, 0.5f, cw - 6, ch - 6, cPanel);
    C2D_DrawRectSolid(cx + 14, cy + 11, 0.5f, cw - 28, 22, cDark);
    text(cx + 22, cy + 14, 0.42f, cAccent, "MX TAPE", 0);
    text(cx + cw - 22, cy + 14, 0.42f, cMuted, "SIDE A", C2D_AlignRight);
    C2D_DrawRectSolid(cx + 62, cy + 54, 0.5f, cw - 124, 24, cDark);
    draw_reel(cx + 52, cy + 66, 9.0f + 13.0f * (1.0f - p), reelAngle);
    draw_reel(cx + cw - 52, cy + 66, 9.0f + 13.0f * p, reelAngle);
    C2D_DrawRectSolid(cx + 44, cy + ch - 15, 0.5f, cw - 88, 12, cDark);

    /* title + artist */
    const char *path = current_path();
    if (path && player_is_open()) {
        const char *ti = player_title();
        const char *ar = player_artist();
        char name[256];
        if (!ti[0]) { display_name(path, name, sizeof name); ti = name; }
        text_fit(TOP_W / 2, 140, 0.72f, cText, ti, 370, C2D_AlignCenter);
        snprintf(buf, sizeof buf, "%s%s%d / %d", ar[0] ? ar : "", ar[0] ? "   ·   " : "", qpos + 1, queue.count);
        text_fit(TOP_W / 2, 166, 0.48f, cMuted, buf, 370, C2D_AlignCenter);
    } else {
        text(TOP_W / 2, 140, 0.72f, cText, "Nothing playing", C2D_AlignCenter);
        text(TOP_W / 2, 166, 0.48f, cMuted, "Pick a track on the bottom screen", C2D_AlignCenter);
    }

    /* visualiser */
    float bx = 40, bw = 7, gap = 3, base = 214;
    for (int i = 0; i < BARS; i++) {
        float h = 2.0f + levels[i] * 22.0f;
        C2D_DrawRectSolid(bx + i * (bw + gap), base - h, 0.5f, bw, h, cAccent);
    }

    /* progress */
    C2D_DrawRectSolid(40, 224, 0.5f, 250, 3, cDim);
    C2D_DrawRectSolid(40, 224, 0.5f, 250 * p, 3, cAccent);
    fmt_time(el, t1, sizeof t1);
    fmt_time(len, t2, sizeof t2);
    snprintf(buf, sizeof buf, "%s %s / %s", player_is_paused() ? "||" : ">", t1, t2);
    text(TOP_W - 40, 217, 0.45f, cMuted, buf, C2D_AlignRight);
}

static void draw_bottom(void) {
    char buf[300];
    int v = view();

    /* tabs */
    text(80, 5, 0.5f, tab == 0 ? cAccent : cMuted, "LIBRARY", C2D_AlignCenter);
    text(240, 5, 0.5f, tab == 1 ? cAccent : cMuted, "PLAYLISTS", C2D_AlignCenter);
    C2D_DrawRectSolid(0, 26, 0.5f, BOT_W, 1, cDim);
    C2D_DrawRectSolid(tab == 0 ? 40 : 200, 24, 0.5f, 80, 2, cAccent);

    /* header */
    if (v == VIEW_LIB) snprintf(buf, sizeof buf, "%d tracks in /music", lib.count);
    else if (v == VIEW_PLAYLISTS) snprintf(buf, sizeof buf, "%d playlists", plCount);
    else snprintf(buf, sizeof buf, "< %s  (%d)", openPl >= 0 ? pls[openPl].name : "", plTracks.count);
    text_fit(8, 29, 0.45f, cMuted, buf, 300, 0);

    /* rows */
    int n = view_count(v);
    const char *playing = player_is_open() ? current_path() : NULL;
    if (n == 0) {
        if (v == VIEW_LIB) {
            text(BOT_W / 2, 90, 0.5f, cText, "No MP3s found", C2D_AlignCenter);
            text(BOT_W / 2, 112, 0.45f, cMuted, "Put them in sdmc:/music/", C2D_AlignCenter);
        } else if (v == VIEW_PLAYLISTS) {
            text(BOT_W / 2, 90, 0.5f, cText, "No playlists yet", C2D_AlignCenter);
            text(BOT_W / 2, 112, 0.45f, cMuted, "Add .m3u files to sdmc:/music/", C2D_AlignCenter);
        } else {
            text(BOT_W / 2, 90, 0.5f, cText, "No matching tracks", C2D_AlignCenter);
            text(BOT_W / 2, 112, 0.45f, cMuted, "Copy the playlist's MP3s to /music", C2D_AlignCenter);
        }
    }
    for (int r = 0; r < ROWS; r++) {
        int i = topRow[v] + r;
        if (i >= n) break;
        float y = LIST_Y + r * ROW_H;
        bool isSel = (i == sel[v]);
        if (isSel) C2D_DrawRectSolid(4, y, 0.5f, BOT_W - 8, ROW_H - 2, cAccent);
        u32 col = isSel ? cInk : cText;
        char name[256];
        const char *label;
        bool isNow = false;
        if (v == VIEW_PLAYLISTS) {
            label = pls[i].name;
        } else {
            const char *p = (v == VIEW_LIB) ? lib.paths[i] : plTracks.paths[i];
            display_name(p, name, sizeof name);
            label = name;
            isNow = playing && strcmp(p, playing) == 0;
        }
        if (isNow) text(10, y + 2, 0.48f, isSel ? cInk : cAccent, ">", 0);
        text_fit(24, y + 2, 0.48f, col, label, BOT_W - 40, 0);
    }

    /* footer */
    C2D_DrawRectSolid(0, 214, 0.5f, BOT_W, 1, cDim);
    if (!audioOk)
        text(BOT_W / 2, 219, 0.42f, cAccent, "Audio failed to start (see README)", C2D_AlignCenter);
    else
        text(BOT_W / 2, 219, 0.42f, cMuted, "A play  B back  Y pause  X shuffle  L/R tab", C2D_AlignCenter);
}

/* ---------- main ---------- */

int main(void) {
    gfxInitDefault();
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();
    C3D_RenderTarget *top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget *bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    g_tb = C2D_TextBufNew(8192);

    ptmuInit();
    gspLcdInit();
    srand((unsigned)osGetTime());
    hidSetRepeatParameters(18, 5);

    cBg     = C2D_Color32(0x05, 0x05, 0x05, 0xFF);
    cPanel  = C2D_Color32(0x14, 0x14, 0x16, 0xFF);
    cDark   = C2D_Color32(0x0A, 0x0A, 0x0B, 0xFF);
    cAccent = C2D_Color32(0xFF, 0xB5, 0x47, 0xFF);
    cText   = C2D_Color32(0xED, 0xED, 0xED, 0xFF);
    cMuted  = C2D_Color32(0x9B, 0x9B, 0x9B, 0xFF);
    cDim    = C2D_Color32(0x2A, 0x2A, 0x2E, 0xFF);
    cTape   = C2D_Color32(0x3A, 0x2E, 0x22, 0xFF);
    cInk    = C2D_Color32(0x0B, 0x0B, 0x0B, 0xFF);

    tl_init(&queue);
    tl_init(&plTracks);
    library_scan(MUSIC_DIR, &lib);
    plCount = playlists_scan(MUSIC_DIR, pls, MAX_PLAYLISTS);
    audioOk = player_init();

    u8 lastShell = 1;
    bool sleepAllowed = true;

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        u32 kRep = hidKeysDownRepeat();
        if (kDown & KEY_START) break;

        int v = view();
        if (kRep & KEY_UP)   { sel[v]--; clamp_view(v); }
        if (kRep & KEY_DOWN) { sel[v]++; clamp_view(v); }
        if (kDown & KEY_A) activate();
        if (kDown & KEY_B) { if (v == VIEW_PL_TRACKS) inPlaylist = false; }
        if (kDown & KEY_Y) player_toggle_pause();
        if (kDown & KEY_X) toggle_shuffle();
        if (kDown & KEY_LEFT)  prev_track();
        if (kDown & KEY_RIGHT) next_track();
        if (kDown & KEY_L) tab = 0;
        if (kDown & KEY_R) tab = 1;

        if (kDown & KEY_TOUCH) {
            touchPosition tp;
            hidTouchRead(&tp);
            if (tp.py < 26) {
                tab = tp.px < BOT_W / 2 ? 0 : 1;
            } else if (tp.py < LIST_Y) {
                if (view() == VIEW_PL_TRACKS) inPlaylist = false;
            } else if (tp.py < LIST_Y + ROWS * ROW_H) {
                int cv = view();
                int i = topRow[cv] + (tp.py - LIST_Y) / ROW_H;
                if (i < view_count(cv)) {
                    if (i == sel[cv]) activate();
                    else sel[cv] = i;
                }
            }
        }

        /* audio */
        player_update();
        if (player_finished()) next_track();

        /* lid closed while playing: screens off, music keeps going */
        u8 shell = 1;
        PTMU_GetShellState(&shell);
        if (shell != lastShell) {
            if (shell == 0) GSPLCD_PowerOffBacklight(GSPLCD_SCREEN_BOTH);
            else GSPLCD_PowerOnBacklight(GSPLCD_SCREEN_BOTH);
            lastShell = shell;
        }
        bool playingNow = player_is_open() && !player_is_paused();
        if (sleepAllowed == playingNow) {
            sleepAllowed = !playingNow;
            aptSetSleepAllowed(sleepAllowed);
        }

        /* visualiser smoothing */
        float raw[BARS];
        player_levels(raw, BARS);
        for (int i = 0; i < BARS; i++)
            levels[i] = raw[i] > levels[i] ? raw[i] : levels[i] * 0.86f + raw[i] * 0.14f;
        if (playingNow) reelAngle += 0.07f;

        C2D_TextBufClear(g_tb);
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(top, cBg);
        C2D_SceneBegin(top);
        draw_top();
        C2D_TargetClear(bot, cBg);
        C2D_SceneBegin(bot);
        draw_bottom();
        C3D_FrameEnd(0);
    }

    GSPLCD_PowerOnBacklight(GSPLCD_SCREEN_BOTH);
    aptSetSleepAllowed(true);
    player_exit();
    tl_free(&lib);
    tl_free(&plTracks);
    tl_free(&queue);
    free(order);
    gspLcdExit();
    ptmuExit();
    C2D_TextBufDelete(g_tb);
    C2D_Fini();
    C3D_Fini();
    gfxExit();
    return 0;
}
