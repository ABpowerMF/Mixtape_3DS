#pragma once
#include <stdbool.h>

bool player_init(void);           /* false if the DSP couldn't start */
void player_exit(void);

bool player_open(const char *path);
void player_stop(void);
void player_update(void);         /* call every frame: refills audio buffers */
void player_toggle_pause(void);

bool player_is_open(void);
bool player_is_paused(void);
bool player_finished(void);       /* reached the end of the track */

double player_elapsed(void);      /* seconds */
double player_length(void);       /* seconds, 0 if unknown */
const char *player_title(void);   /* ID3 title or "" */
const char *player_artist(void);  /* ID3 artist or "" */

/* n spectrum levels 0..1 for the visualiser */
void player_levels(float *out, int n);
