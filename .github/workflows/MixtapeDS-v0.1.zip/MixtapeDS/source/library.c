#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <dirent.h>
#include <sys/stat.h>
#include "library.h"

void tl_init(TrackList *t) {
    t->paths = NULL;
    t->count = 0;
    t->cap = 0;
}

void tl_add(TrackList *t, const char *path) {
    if (t->count >= MAX_TRACKS) return;
    if (t->count == t->cap) {
        int nc = t->cap ? t->cap * 2 : 64;
        char **np = realloc(t->paths, (size_t)nc * sizeof(char *));
        if (!np) return;
        t->paths = np;
        t->cap = nc;
    }
    t->paths[t->count] = strdup(path);
    if (t->paths[t->count]) t->count++;
}

void tl_copy(TrackList *dst, const TrackList *src) {
    tl_init(dst);
    for (int i = 0; i < src->count; i++) tl_add(dst, src->paths[i]);
}

void tl_free(TrackList *t) {
    for (int i = 0; i < t->count; i++) free(t->paths[i]);
    free(t->paths);
    tl_init(t);
}

const char *path_base(const char *path) {
    const char *s = strrchr(path, '/');
    return s ? s + 1 : path;
}

void display_name(const char *path, char *out, size_t n) {
    if (n == 0) return;
    snprintf(out, n, "%s", path_base(path));
    char *dot = strrchr(out, '.');
    if (dot && dot != out) *dot = '\0';
    for (char *c = out; *c; c++)
        if (*c == '_') *c = ' ';
}

static int has_ext(const char *name, const char *ext) {
    size_t n = strlen(name), e = strlen(ext);
    return n > e && strcasecmp(name + n - e, ext) == 0;
}

static int is_dir(const char *path) {
    struct stat st;
    return stat(path, &st) == 0 && S_ISDIR(st.st_mode);
}

static int file_exists(const char *path) {
    struct stat st;
    return stat(path, &st) == 0 && !S_ISDIR(st.st_mode);
}

static void scan_dir(const char *dir, TrackList *out, int depth) {
    if (depth > 5) return;
    DIR *d = opendir(dir);
    if (!d) return;
    struct dirent *ent;
    char path[512];
    while ((ent = readdir(d)) != NULL) {
        if (ent->d_name[0] == '.') continue;
        snprintf(path, sizeof path, "%s/%s", dir, ent->d_name);
        int dir_flag;
#ifdef DT_DIR
        if (ent->d_type == DT_DIR) dir_flag = 1;
        else if (ent->d_type == DT_REG) dir_flag = 0;
        else dir_flag = is_dir(path);
#else
        dir_flag = is_dir(path);
#endif
        if (dir_flag) scan_dir(path, out, depth + 1);
        else if (has_ext(ent->d_name, ".mp3")) tl_add(out, path);
    }
    closedir(d);
}

static int cmp_base(const void *a, const void *b) {
    const char *pa = *(const char *const *)a;
    const char *pb = *(const char *const *)b;
    return strcasecmp(path_base(pa), path_base(pb));
}

int library_scan(const char *root, TrackList *out) {
    tl_init(out);
    scan_dir(root, out, 0);
    if (out->count > 1) qsort(out->paths, (size_t)out->count, sizeof(char *), cmp_base);
    return out->count;
}

static int scan_playlist_dir(const char *dir, Playlist *out, int count, int max) {
    DIR *d = opendir(dir);
    if (!d) return count;
    struct dirent *ent;
    while ((ent = readdir(d)) != NULL && count < max) {
        if (ent->d_name[0] == '.') continue;
        if (!has_ext(ent->d_name, ".m3u") && !has_ext(ent->d_name, ".m3u8")) continue;
        Playlist *p = &out[count];
        snprintf(p->path, sizeof p->path, "%s/%s", dir, ent->d_name);
        display_name(p->path, p->name, sizeof p->name);
        count++;
    }
    closedir(d);
    return count;
}

static int cmp_playlist(const void *a, const void *b) {
    return strcasecmp(((const Playlist *)a)->name, ((const Playlist *)b)->name);
}

int playlists_scan(const char *root, Playlist *out, int max) {
    char sub[512];
    int count = scan_playlist_dir(root, out, 0, max);
    snprintf(sub, sizeof sub, "%s/playlists", root);
    count = scan_playlist_dir(sub, out, count, max);
    if (count > 1) qsort(out, (size_t)count, sizeof(Playlist), cmp_playlist);
    return count;
}

static void trim(char *s) {
    size_t n = strlen(s);
    while (n > 0 && (s[n - 1] == '\n' || s[n - 1] == '\r' || s[n - 1] == ' ' || s[n - 1] == '\t'))
        s[--n] = '\0';
}

static const char *find_by_name(const TrackList *lib, const char *name) {
    for (int i = 0; i < lib->count; i++)
        if (strcasecmp(path_base(lib->paths[i]), name) == 0) return lib->paths[i];
    return NULL;
}

int playlist_load(const char *m3uPath, const TrackList *library, TrackList *out) {
    tl_init(out);
    FILE *f = fopen(m3uPath, "r");
    if (!f) return 0;

    char dir[512];
    snprintf(dir, sizeof dir, "%s", m3uPath);
    char *slash = strrchr(dir, '/');
    if (slash) *slash = '\0';

    char line[1024], cand[1600];
    int first = 1;
    while (fgets(line, sizeof line, f)) {
        char *s = line;
        if (first) {
            if ((unsigned char)s[0] == 0xEF && (unsigned char)s[1] == 0xBB && (unsigned char)s[2] == 0xBF) s += 3;
            first = 0;
        }
        trim(s);
        while (*s == ' ' || *s == '\t') s++;
        if (*s == '\0' || *s == '#') continue;
        for (char *c = s; *c; c++)
            if (*c == '\\') *c = '/';

        if (strncmp(s, "sdmc:", 5) == 0) snprintf(cand, sizeof cand, "%s", s);
        else if (s[0] == '/') snprintf(cand, sizeof cand, "sdmc:%s", s);
        else snprintf(cand, sizeof cand, "%s/%s", dir, s);

        if (file_exists(cand)) {
            tl_add(out, cand);
        } else {
            const char *hit = find_by_name(library, path_base(s));
            if (hit) tl_add(out, hit);
        }
    }
    fclose(f);
    return out->count;
}
