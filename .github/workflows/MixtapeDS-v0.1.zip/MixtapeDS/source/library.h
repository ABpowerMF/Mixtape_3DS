#pragma once
#include <stddef.h>

#define MAX_TRACKS    4096
#define MAX_PLAYLISTS 128

typedef struct {
    char **paths;
    int count;
    int cap;
} TrackList;

typedef struct {
    char name[128];
    char path[512];
} Playlist;

void tl_init(TrackList *t);
void tl_add(TrackList *t, const char *path);
void tl_copy(TrackList *dst, const TrackList *src);
void tl_free(TrackList *t);

/* All .mp3 files under root (up to 5 folders deep), sorted by file name. */
int library_scan(const char *root, TrackList *out);

/* .m3u / .m3u8 files in root and root/playlists. */
int playlists_scan(const char *root, Playlist *out, int max);

/* Loads a playlist. Entries that don't exist at their path (e.g. Android paths
   exported from Mixtape on the phone) are matched to library tracks by file name. */
int playlist_load(const char *m3uPath, const TrackList *library, TrackList *out);

const char *path_base(const char *path);

/* File name without extension, underscores shown as spaces. */
void display_name(const char *path, char *out, size_t n);
