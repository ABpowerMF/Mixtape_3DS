# Mixtape DS v0.1

A pocket Mixtape for the Nintendo 3DS: now playing on the top screen, library and playlists on the touchscreen.

## Build (GitHub Actions)
1. Make a new repo (e.g. `mixtape-3ds`) and upload everything in this zip, including the hidden `.github` folder.
2. The **Build Mixtape DS** workflow runs on every push. Open the run → **Artifacts** → download `MixtapeDS` → unzip to get `MixtapeDS.3dsx`.

## Try it in Azahar (emulator)
1. In Azahar: **File → Open Azahar Folder** → go into `sdmc`.
2. Make a `music` folder there and copy some MP3s in (subfolders are fine).
3. Optional playlists: put `.m3u` files in `sdmc/music/` or `sdmc/music/playlists/`.
   Android paths from Mixtape on your phone are fine — tracks are matched by file name.
4. **File → Load File** → pick `MixtapeDS.3dsx`.

If the footer says *Audio failed to start*, the 3DS audio system needs `dspfirm.cdc` in `sdmc/3ds/`.
On a real console you create it once with the **DSP1** homebrew; copy that file into the emulator's `sdmc/3ds/` too.

## On the New 3DS XL
Copy `MixtapeDS.3dsx` to `sdmc:/3ds/` and the music to `sdmc:/music/`, then open it from the Homebrew Launcher.

## Controls
| Button | Action |
|---|---|
| D-pad ↑ ↓ / tap | Move / pick (tap again to play) |
| A | Play track / open playlist |
| B / tap header | Back out of a playlist |
| ← → | Previous / next track |
| Y | Pause / resume |
| X | Shuffle on/off |
| L / R / tap tabs | Library / Playlists |
| START | Quit |

Closing the lid while music plays turns the screens off and keeps playing.
